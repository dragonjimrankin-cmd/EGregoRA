/* EGregoRA — starfield, reveals, nav */
(() => {
  "use strict";
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* --- Mobile nav --- */
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("primary-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
      const label = toggle.querySelector("em");
      if (label) label.textContent = open ? "Close" : "Menu";
    });
  }

  /* --- Scroll reveals ---
   *
   * Everything marked .reveal starts at opacity 0 and is faded in when it
   * comes into view. That is a decoration, and a decoration must never be
   * the reason a visitor cannot read the page, so this is deliberately
   * paranoid:
   *
   *   - the threshold is 0, not a fraction. A fractional threshold is the
   *     classic phone bug: the Ask Ed panel is several thousand pixels tall
   *     on a narrow screen, 12% of it is taller than the whole viewport, so
   *     it could never satisfy the observer and simply stayed invisible.
   *   - anything already on screen at load, or scrolled past, is shown at
   *     once rather than waiting for a scroll that may never come.
   *   - if there is no IntersectionObserver, or the observer has not fired
   *     within a couple of seconds, everything is revealed outright.
   */
  const reveals = Array.prototype.slice.call(document.querySelectorAll(".reveal"));
  const show = (el) => el.classList.add("in");

  /* The fade only exists once this script is running. Without the class the
     stylesheet leaves every panel visible, so a script that fails to load,
     is blocked, or throws can never hide the page. */
  document.documentElement.classList.add("js-reveals");

  if (!("IntersectionObserver" in window)) {
    reveals.forEach(show);
  } else {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting || e.intersectionRatio > 0) { show(e.target); io.unobserve(e.target); }
      }),
      { threshold: 0, rootMargin: "120px 0px 120px 0px" }
    );
    reveals.forEach((el) => io.observe(el));

    /* Belt and braces: anything whose top is already above the fold. */
    const sweep = () => {
      const h = window.innerHeight || document.documentElement.clientHeight;
      reveals.forEach((el) => {
        if (el.classList.contains("in")) return;
        const r = el.getBoundingClientRect();
        if (r.top < h + 120 && r.bottom > -120) show(el);
      });
    };
    sweep();
    window.addEventListener("load", sweep, { once: true });
    setTimeout(sweep, 400);
    /* If nothing at all has been revealed after a few seconds the observer
       is not working on this device. Show everything rather than leave the
       visitor with a blank page. */
    setTimeout(() => {
      if (!reveals.some((el) => el.classList.contains("in"))) reveals.forEach(show);
    }, 3000);
  }

  /* --- Starfield + slow nebula drift --- */
  const cv = document.getElementById("starfield");
  if (!cv || reduce) return;
  const ctx = cv.getContext("2d");
  let w, h, stars, dpr;

  function seed() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = cv.width = innerWidth * dpr;
    h = cv.height = innerHeight * dpr;
    const count = Math.min(380, Math.floor((innerWidth * innerHeight) / 5200));
    stars = Array.from({ length: count }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: (Math.random() * 1.25 + 0.25) * dpr,
      a: Math.random(),
      s: Math.random() * 0.012 + 0.002,
      hue: Math.random() < 0.18 ? "215,176,90" : Math.random() < 0.3 ? "155,125,219" : "239,227,200"
    }));
  }

  function draw() {
    ctx.clearRect(0, 0, w, h);
    for (const st of stars) {
      st.a += st.s;
      const alpha = 0.25 + Math.abs(Math.sin(st.a)) * 0.7;
      ctx.beginPath();
      ctx.arc(st.x, st.y, st.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${st.hue},${alpha.toFixed(3)})`;
      ctx.fill();
      st.y += st.r * 0.012;
      if (st.y > h + 2) { st.y = -2; st.x = Math.random() * w; }
    }
    requestAnimationFrame(draw);
  }

  seed();
  draw();
  let t;
  addEventListener("resize", () => { clearTimeout(t); t = setTimeout(seed, 200); });
})();

/* ------------------------------------------------------------------ Oracle
   A conversational client for /api/ask. Keeps the thread in memory, sends the
   last turns with each question so the oracle can follow a line of enquiry,
   renders a transcript, streams the answer in word by word, offers follow-up
   chips, and hands the finished text to Gink to read aloud. */
(() => {
  "use strict";
  const form = document.getElementById("oracle-form");
  if (!form) return;

  const thread = document.getElementById("oracle-thread");
  const chips = document.getElementById("oracle-chips");
  const box = document.getElementById("o-question");
  const btn = document.getElementById("o-submit");
  const reset = document.getElementById("o-reset");
  const wipe = document.getElementById("o-wipe");
  const nameEl = document.getElementById("o-name");
  const limbEl = document.getElementById("o-limb");
  if (!thread || !box || !btn) return;

  const fileInput = document.getElementById("o-files");
  const fileList = document.getElementById("o-file-list");

  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const MAX_KEPT = 16;                 // turns held in the client thread
  let history = [];                    // [{ role, text }]
  let busy = false;
  let attachments = [];                // [{ id, name, kind, chars }]

  const esc = (s) =>
    String(s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* A deliberately small amount of markdown: the order's answers use bold,
     italics, em dashes and the ◆ grading marks, and nothing else. */
  const rich = (text) => esc(text)
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/(^|[\s(])\*([^*\n]+)\*/g, "$1<em>$2</em>")
    /* markdown links, which the oracle uses when it has searched the web */
    .replace(/\[([^\]\n]+)\]\((https?:&#39;?\/\/[^\s)]+|https?:\/\/[^\s)]+)\)/g,
      (m, label, url) => '<a href="' + url + '" target="_blank" rel="noopener nofollow">' + label + "</a>")
    /* bare URLs left in the prose */
    .replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g,
      (m, pre, url) => pre + '<a href="' + url + '" target="_blank" rel="noopener nofollow">' + url + "</a>")
    .replace(/\n/g, "\n");

  const paragraphs = (text) =>
    rich(text).split(/\n{2,}/).map((p) => {
      const lines = p.split("\n");
      if (lines.every((l) => /^\s*[—\-•]\s+/.test(l)) && lines.length > 1) {
        return "<ul>" + lines.map((l) =>
          "<li>" + l.replace(/^\s*[—\-•]\s+/, "") + "</li>").join("") + "</ul>";
      }
      return "<p>" + lines.join("<br>") + "</p>";
    }).join("");

  const scrollThread = () => {
    thread.scrollTop = thread.scrollHeight;
  };

  /* Bring the answer box itself into view. The transcript sits directly
     under the question box, so on a long page the reply can begin below the
     fold; this walks the page down to it once per asking. */
  const scrollToAnswer = () => {
    const room = thread.closest(".oracle-chat") || thread;
    const top = room.getBoundingClientRect().top;
    if (top > 80 || top < 0) {
      room.scrollIntoView({
        block: "start",
        behavior: reduce ? "auto" : "smooth"
      });
    }
  };

  const addMsg = (role, html, cls) => {
    const el = document.createElement("div");
    el.className = "oracle-msg oracle-msg--" + role + (cls ? " " + cls : "");
    el.innerHTML =
      '<p class="oracle-who">' + (role === "you" ? "You" : "The Oracle") + "</p>" +
      '<div class="oracle-text">' + html + "</div>";
    const waiting = document.getElementById("oracle-waiting");
    if (waiting) waiting.hidden = true;
    thread.appendChild(el);
    scrollThread();
    return el;
  };

  const thinking = () => {
    const el = addMsg("oracle", '<p class="oracle-dots"><i></i><i></i><i></i></p>', "is-thinking");
    return el;
  };

  /* Reveal an answer a few words at a time, which is what makes a reply feel
     answered rather than pasted. Instant under reduced-motion. */
  const reveal = (el, text, done) => {
    const target = el.querySelector(".oracle-text");
    if (reduce) { target.innerHTML = paragraphs(text); scrollThread(); done && done(); return; }
    const words = text.split(/(\s+)/);
    let i = 0;
    const step = () => {
      i = Math.min(words.length, i + 3);
      target.innerHTML = paragraphs(words.slice(0, i).join(""));
      scrollThread();
      if (i < words.length) setTimeout(step, 16);
      else done && done();
    };
    step();
  };

  const setChips = (list) => {
    if (!chips) return;
    chips.innerHTML = "";
    if (!list || !list.length) { chips.hidden = true; return; }
    chips.hidden = false;
    list.forEach((q) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "chip";
      b.textContent = q;
      chips.appendChild(b);
    });
  };

  /* Pictures the oracle drew for this reply. */
  const attachImages = (el, data) => {
    if (!data.images || !data.images.length) return;
    const wrap = document.createElement("div");
    wrap.className = "oracle-art";
    data.images.slice(0, 3).forEach((img) => {
      if (!img || !img.url) return;
      const fig = document.createElement("figure");
      fig.innerHTML =
        '<a href="' + esc(img.url) + '" target="_blank" rel="noopener">' +
        '<img src="' + esc(img.url) + '" alt="' +
        esc(img.prompt || "An image drawn by the oracle") + '" loading="lazy"></a>' +
        '<figcaption>Drawn just now by the oracle \u00b7 generated, not photographed' +
        (img.prompt ? " \u00b7 " + esc(String(img.prompt).slice(0, 160)) : "") + "</figcaption>";
      wrap.appendChild(fig);
    });
    if (wrap.children.length) {
      el.appendChild(wrap);
      scrollThread();
      if (window.EGArrived) window.EGArrived("oracle-image", wrap);
    }
  };

  /* Provenance — where the answer came from, which model wrote it, what it was
     grounded in — is deliberately NOT shown. It belongs in the server log, not
     in the conversation. Only things the reader can act on survive here: links
     the oracle actually followed, and a note it wrote itself. */
  const footnote = (el, data) => {
    const bits = [];
    if (data.sources && data.sources.length) {
      bits.push("looked up on the web: " + data.sources.slice(0, 4).map((s) =>
        '<a href="' + esc(s.url) + '" target="_blank" rel="noopener nofollow">' +
        esc(s.title || s.url).slice(0, 60) + "</a>").join(", "));
    }
    if (data.note) bits.push(esc(data.note));
    if (!bits.length) return;
    const p = document.createElement("p");
    p.className = "oracle-src";
    p.innerHTML = bits.join(" \u00b7 ");
    el.appendChild(p);
  };

  /* ---- files handed to the oracle ---- */
  const renderFiles = () => {
    if (!fileList) return;
    fileList.innerHTML = "";
    attachments.forEach((f) => {
      const li = document.createElement("li");
      li.className = "file-chip" + (f.pending ? " is-pending" : "") + (f.error ? " is-error" : "");
      li.innerHTML =
        '<span class="file-name">' + esc(f.name) + "</span>" +
        '<span class="file-meta">' + esc(
          f.pending ? "reading\u2026" :
          f.error ? f.error :
          f.kind === "image" ? "image \u00b7 held as reference" :
          (f.chars || 0).toLocaleString() + " characters read") + "</span>";
      if (!f.pending) {
        const x = document.createElement("button");
        x.type = "button";
        x.className = "file-x";
        x.setAttribute("aria-label", "Remove " + f.name);
        x.textContent = "\u00d7";
        x.addEventListener("click", () => {
          attachments = attachments.filter((a) => a !== f);
          renderFiles();
        });
        li.appendChild(x);
      }
      fileList.appendChild(li);
    });
  };

  const readAsBase64 = (file) => new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result).split(",").pop());
    fr.onerror = () => reject(new Error("unreadable"));
    fr.readAsDataURL(file);
  });

  const sendFile = async (file) => {
    const entry = { name: file.name, pending: true };
    attachments.push(entry);
    renderFiles();
    try {
      if (file.size > 4 * 1024 * 1024) throw new Error("larger than 4 MB");
      const data = await readAsBase64(file);
      const res = await fetch("/api/upload", {
        method: "POST",
        headers: window.EGAuthHeaders ? window.EGAuthHeaders() : { "content-type": "application/json" },
        body: JSON.stringify({
          name: file.name, type: file.type, data,
          asker: (nameEl && nameEl.value || "").trim()
        })
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok || !out.id) throw new Error(out.error || "could not be read");
      Object.assign(entry, out, { pending: false });
    } catch (err) {
      entry.pending = false;
      entry.error = (err && err.message) || "failed";
    }
    renderFiles();
  };

  if (fileInput) fileInput.addEventListener("change", () => {
    Array.from(fileInput.files || []).slice(0, 6).forEach(sendFile);
    fileInput.value = "";
  });

  const ask = async (question) => {
    if (busy) return;
    const q = String(question || "").trim();
    if (q.length < 2) return;

    busy = true;
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = "Consulting\u2026";
    setChips([]);

    const ready = attachments.filter((f) => f.id);
    addMsg("you", paragraphs(q) + (ready.length
      ? '<p class="oracle-attached">Attached: ' +
        ready.map((f) => esc(f.name)).join(", ") + "</p>"
      : ""));
    history.push({ role: "user", text: q });
    box.value = "";
    box.style.height = "";

    const pending = thinking();
    scrollToAnswer();

    try {
      const res = await fetch("/api/ask", {
        method: "POST",
        headers: window.EGAuthHeaders ? window.EGAuthHeaders() : { "content-type": "application/json" },
        body: JSON.stringify({
          question: q,
          name: (nameEl && nameEl.value || "").trim(),
          limb: (limbEl && limbEl.value) || "",
          history: history.slice(0, -1).slice(-MAX_KEPT),
          attachments: attachments.filter((f) => f.id).map((f) => f.id),
          byok: window.EGOwnMind ? window.EGOwnMind() : null,
          /* An administrator with the door open on this page also opens the
             order's own Free.ai keys, with whichever model was chosen in
             the Free.ai panel. Nobody else sends any of this. */
          pass: (window.EGAdminPass && window.EGAdminPass()) || undefined,
          free_model: (window.EGFreeWants && window.EGFreeWants().chat) || undefined,
          free_slot: (window.EGFreeWants && window.EGFreeWants().slot) || undefined
        })
      });
      const data = await res.json().catch(() => ({}));

      pending.classList.remove("is-thinking");

      if (!res.ok || !data.answer) {
        pending.querySelector(".oracle-text").innerHTML =
          "<p>" + esc(data.error || "The oracle is silent just now. The written form below still reaches Ed.") + "</p>";
        pending.classList.add("is-error");
        history.pop();
      } else {
        reveal(pending, data.answer, () => {
          attachImages(pending, data);
          if (data.videos && data.videos.length && window.EGFilmWatch) {
            data.videos.forEach((v) => { if (v && v.id) window.EGFilmWatch(v.id, v.prompt); });
          }
          footnote(pending, data);
          setChips(data.followups);
          scrollThread();
        });
        history.push({ role: "oracle", text: data.answer });
        if (history.length > MAX_KEPT) history = history.slice(-MAX_KEPT);
        if (window.EGVoiceMuted && window.EGVoiceMuted()) {
          /* Gink's voice is off; the answer is read with the eyes. */
        } else if (window.EGFox && window.EGFox.available) {
          window.EGFox.speak(data.answer);
        } else {
          window.__EG_PENDING_SPEECH__ = data.answer;
        }
      }
    } catch {
      pending.classList.remove("is-thinking");
      pending.classList.add("is-error");
      pending.querySelector(".oracle-text").innerHTML =
        "<p>No answer could be fetched \u2014 this page may be running without its backend. " +
        "The written form below still reaches Ed.</p>";
      history.pop();
    } finally {
      busy = false;
      btn.disabled = false;
      btn.textContent = label;
      box.focus();
    }
  };

  const expand = document.getElementById("o-expand");
  if (expand) expand.addEventListener("click", () => {
    const on = document.body.classList.toggle("oracle-tall");
    expand.setAttribute("aria-pressed", on ? "true" : "false");
    expand.textContent = on ? "Shrink the space" : "Expand the space";
    try { localStorage.setItem("eg-oracle-tall", on ? "1" : "0"); } catch {}
    scrollThread();
  });
  try {
    if (localStorage.getItem("eg-oracle-tall") === "1" && expand) expand.click();
  } catch {}

  form.addEventListener("submit", (e) => { e.preventDefault(); ask(box.value); });

  // Enter sends, Shift+Enter makes a new line
  box.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      form.requestSubmit ? form.requestSubmit() : ask(box.value);
    }
  });

  // grow the box with the question
  const grow = () => {
    box.style.height = "auto";
    box.style.height = Math.min(box.scrollHeight, 240) + "px";
  };
  box.addEventListener("input", grow);

  if (chips) chips.addEventListener("click", (e) => {
    const b = e.target.closest(".chip");
    if (b) ask(b.textContent);
  });

  /* Clear Prompt empties the box you are typing in and nothing else — the
     conversation above it is left exactly where it was. */
  if (reset) reset.addEventListener("click", () => {
    box.value = "";
    box.style.height = "";
    box.focus();
  });

  /* Full Reset is the old "begin again": the thread is forgotten, the
     opening chips come back, Gink stops talking and the box is emptied. */
  if (wipe) wipe.addEventListener("click", () => {
    history = [];
    attachments = [];
    if (fileList) fileList.innerHTML = "";
    if (fileInput) fileInput.value = "";
    thread.querySelectorAll(".oracle-msg:not(.oracle-greet)").forEach((n) => n.remove());
    const waiting = document.getElementById("oracle-waiting");
    if (waiting) waiting.hidden = false;
    setChips([
      "Is the meaning of life 42 or chicken soup?",
      "Why 137.5 degrees and not 120?",
      "Is the Law of One testable?",
      "Did the druids really build Stonehenge?",
      "What does a psychedelic actually do to a brain?",
      "Is magic real, in one paragraph?"
    ]);
    if (window.EGFox) window.EGFox.stop();
    box.value = "";
    box.style.height = "";
    box.focus();
  });
})();

/* ------------------------------------------------- Hold-to-speak microphone
   Push-to-talk for the oracle, using the browser's own SpeechRecognition.
   Hold the button (pointer or space bar), speak, release. The transcript is
   written into the question box; if it looks like a complete question the
   form is submitted for you. Nothing is uploaded by this code — recognition
   is the browser's, and in Chrome it goes to Google's speech service exactly
   as it does for any other site that uses the API. Say so plainly rather
   than pretend otherwise. */
(() => {
  "use strict";
  const btn = document.getElementById("o-mic");
  const form = document.getElementById("oracle-form");
  const box = document.getElementById("o-question");
  const hint = document.getElementById("o-mic-hint");
  if (!btn || !form || !box) return;

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    btn.hidden = true;
    if (hint) {
      hint.innerHTML = "This browser has no speech recognition, so the hold-to-speak " +
        "button is hidden. Firefox and most in-app browsers are in this group. Type the question instead — " +
        "the oracle answers identically either way.";
    }
    return;
  }
  btn.hidden = false;

  const label = btn.querySelector(".mic-label");
  const setLabel = (s) => { if (label) label.textContent = s; };

  let rec = null;
  let active = false;
  let committed = "";   // finalised text from this hold
  let before = "";      // whatever was already in the box
  let gotSpeech = false;
  let holdStart = 0;

  const fox = () => (window.EGFox && typeof window.EGFox.listen === "function") ? window.EGFox : null;

  const start = () => {
    if (active) return;
    active = true;
    gotSpeech = false;
    committed = "";
    holdStart = Date.now();
    before = box.value.trim();
    btn.classList.add("is-listening");
    setLabel("Listening…");
    fox()?.listen(true);

    rec = new SR();
    rec.lang = document.documentElement.lang || "en-GB";
    rec.continuous = true;
    rec.interimResults = true;
    rec.maxAlternatives = 1;

    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) committed += r[0].transcript + " ";
        else interim += r[0].transcript;
      }
      gotSpeech = gotSpeech || !!(committed.trim() || interim.trim());
      const joined = (before ? before + " " : "") + (committed + interim).replace(/\s+/g, " ").trim();
      box.value = joined;
      box.dispatchEvent(new Event("input", { bubbles: true }));
    };

    rec.onerror = (e) => {
      const why = {
        "not-allowed": "Microphone permission was refused. Allow it in the padlock menu, or type instead.",
        "service-not-allowed": "This browser will not run speech recognition on this page. Type instead.",
        "no-speech": "Nothing was heard. Hold the button, speak, then release.",
        "audio-capture": "No microphone was found on this device.",
        "network": "Speech recognition needs a connection and could not reach its service."
      }[e.error] || "Speech recognition stopped unexpectedly. Type the question instead.";
      if (hint) hint.textContent = why;
      finish(true);
    };

    rec.onend = () => { if (active) finish(false); };

    try { rec.start(); }
    catch { finish(true); }
  };

  const finish = (quiet) => {
    if (!active) return;
    active = false;
    btn.classList.remove("is-listening");
    setLabel("Hold to speak");
    fox()?.listen(false);
    try { rec && rec.stop(); } catch {}
    rec = null;

    const held = Date.now() - holdStart;
    const text = box.value.trim();

    if (!quiet && held < 350) {
      if (hint) hint.textContent = "Hold the button down while you speak — a tap is too short to hear anything.";
      return;
    }
    if (!gotSpeech) return;

    // tidy the transcript: capitalise, and add a question mark if it asks something
    let tidy = text.replace(/\s+/g, " ").trim();
    if (tidy) {
      tidy = tidy.charAt(0).toUpperCase() + tidy.slice(1);
      if (!/[.?!]$/.test(tidy)) {
        tidy += /^(who|what|when|where|why|how|is|are|was|were|do|does|did|can|could|should|would|will|if)\b/i
          .test(tidy) ? "?" : ".";
      }
      box.value = tidy;
    }

    if (tidy.length >= 8) {
      if (hint) hint.textContent = "Heard you. Consulting the order…";
      form.requestSubmit
        ? form.requestSubmit()
        : form.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }));
    } else if (hint) {
      hint.textContent = "That was too short to work with. Hold again and ask a fuller question.";
    }
  };

  btn.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    btn.setPointerCapture?.(e.pointerId);
    start();
  });
  ["pointerup", "pointercancel", "pointerleave"].forEach((ev) =>
    btn.addEventListener(ev, () => finish(false)));
  btn.addEventListener("contextmenu", (e) => e.preventDefault());

  btn.addEventListener("keydown", (e) => {
    if ((e.key === " " || e.key === "Enter") && !e.repeat) { e.preventDefault(); start(); }
  });
  btn.addEventListener("keyup", (e) => {
    if (e.key === " " || e.key === "Enter") { e.preventDefault(); finish(false); }
  });
  btn.addEventListener("blur", () => finish(false));
  document.addEventListener("visibilitychange", () => { if (document.hidden) finish(true); });
})();

/* ------------------------------------------------- Floating scroll arrows
   A small rail of two arrows, fixed to the right edge. Each one appears only
   when there is actually somewhere to go in that direction, so on a short
   page neither is drawn, and at the foot of a long one only the up arrow is.
   Hidden entirely for anyone who has asked for reduced motion to stay put —
   no, in fact they still work, they simply jump instead of gliding. */
(() => {
  "use strict";
  const rail = document.getElementById("scroll-rail");
  const up = document.getElementById("scroll-top");
  const down = document.getElementById("scroll-bottom");
  if (!rail || !up || !down) return;

  const SLACK = 24;           // px of travel below which there is nothing to do
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const behavior = reduce ? "auto" : "smooth";

  const scroller = document.scrollingElement || document.documentElement;

  const update = () => {
    const y = window.scrollY || scroller.scrollTop || 0;
    const max = Math.max(0, scroller.scrollHeight - window.innerHeight);
    const canUp = y > SLACK;
    const canDown = max - y > SLACK;

    /* Each arrow keeps its slot in the rail whether or not it is shown, so
       the surviving one does not jump when the other goes. The rail itself
       only disappears when neither direction has anywhere to go. */
    up.classList.toggle("is-off", !canUp);
    down.classList.toggle("is-off", !canDown);
    up.disabled = !canUp;
    down.disabled = !canDown;
    up.setAttribute("aria-hidden", canUp ? "false" : "true");
    down.setAttribute("aria-hidden", canDown ? "false" : "true");
    up.tabIndex = canUp ? 0 : -1;
    down.tabIndex = canDown ? 0 : -1;
    rail.hidden = !(canUp || canDown);
    rail.setAttribute("aria-hidden", rail.hidden ? "true" : "false");
  };

  const go = (to) => window.scrollTo({ top: to, behavior });
  up.addEventListener("click", () => go(0));
  down.addEventListener("click", () =>
    go(Math.max(0, scroller.scrollHeight - window.innerHeight)));

  let ticking = false;
  const onScroll = () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => { update(); ticking = false; });
  };

  addEventListener("scroll", onScroll, { passive: true });
  addEventListener("resize", onScroll);
  addEventListener("load", update);
  // the page grows as reveal animations and Gink's canvas settles in
  if (window.ResizeObserver) {
    new ResizeObserver(onScroll).observe(document.body);
  }
  update();
})();


/* ------------------------------------------------------- Progress bars
 * One bar, used by every generator on the page.
 *
 * Two kinds of number can arrive and the bar never pretends they are the
 * same. A MEASURED percentage is the sampler's own step counter, reported by
 * the GPU doing the work. An ESTIMATED one is this page reading the clock
 * against how long the route usually takes — it eases towards 94% and stops
 * there, because a bar that sits at 99% is a lie and one that hits 100%
 * before the file exists is a worse one. The label says which you are
 * looking at, and the line beneath says which machine is doing the work.
 * ------------------------------------------------------------------ */
(function () {
  window.EGBar = function (card, opts) {
    opts = opts || {};
    var wrap = card.querySelector('.gen-wait');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.className = 'gen-wait';
      card.insertBefore(wrap, card.firstChild);
    }
    wrap.innerHTML =
      '<div class="gen-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">' +
      '<span></span></div>' +
      '<p class="gen-line"><strong class="gen-pct">0%</strong>' +
      '<span class="gen-kind">estimated from the clock</span></p>' +
      '<p class="gen-note">' + (opts.note || 'Working\u2026') + '</p>' +
      '<p class="gen-gpu">Looking for a machine\u2026</p>';

    var box  = wrap.querySelector('.gen-bar');
    var fill = wrap.querySelector('.gen-bar span');
    var pct  = wrap.querySelector('.gen-pct');
    var kind = wrap.querySelector('.gen-kind');
    var note = wrap.querySelector('.gen-note');
    var gpu  = wrap.querySelector('.gen-gpu');

    var shown = 0;
    var measured = false;
    var expect = Number(opts.expect) || 30;
    var t0 = Date.now();

    function paint(v) {
      var n = Math.min(100, Math.max(0, Math.round(v)));
      if (n <= shown) return;
      shown = n;
      fill.style.width = n + '%';
      pct.textContent = n + '%';
      box.setAttribute('aria-valuenow', String(n));
      if (n >= 100) box.classList.add('is-full');
    }

    function creep() {
      if (measured) return;
      var f = ((Date.now() - t0) / 1000) / expect;
      paint(94 * (1 - Math.exp(-2.2 * f)));
    }

    var timer = setInterval(creep, 700);
    creep();

    return {
      set: function (v, isMeasured, stage) {
        if (isMeasured && !measured) {
          measured = true;
          kind.textContent = 'measured on the GPU';
        }
        if (typeof v === 'number' && v > 0) paint(v);
        if (stage) note.textContent = stage;
      },
      gpu: function (text) { if (text) gpu.textContent = text; },
      note: function (text) { if (text) note.textContent = text; },
      done: function () { measured = true; clearInterval(timer); paint(100); },
      stop: function () { clearInterval(timer); }
    };
  };
})();

/* ------------------------------------------------------------- Drawing box
   A direct line to /api/draw: a prompt in, one finished image out, with no
   model and no conversation in between. */
(() => {
  "use strict";
  const form = document.getElementById("draw-form");
  if (!form) return;

  const box = document.getElementById("d-prompt");
  const btn = document.getElementById("d-submit");
  const clear = document.getElementById("d-clear");
  const out = document.getElementById("draw-out");
  const examples = document.getElementById("draw-examples");
  const nameEl = document.getElementById("o-name");
  if (!box || !btn || !out) return;

  let busy = false;

  const esc = (s) =>
    String(s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const draw = async (prompt) => {
    const p = String(prompt || "").trim();
    if (busy || p.length < 3) return;

    busy = true;
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = "Generating\u2026";
    if (clear) clear.hidden = false;

    const card = document.createElement("figure");
    card.className = "draw-card is-working";
    card.innerHTML = '<figcaption>' + esc(p) + "</figcaption>";
    const bar = window.EGBar(card, { note: "Drawing \u2014 fifteen to forty seconds.", expect: 28 });
    out.prepend(card);
    card.scrollIntoView({ block: "nearest", behavior: "smooth" });

    try {
      const res = await fetch("/api/draw", {
        method: "POST",
        headers: window.EGAuthHeaders ? window.EGAuthHeaders() : { "content-type": "application/json" },
        body: JSON.stringify({
          prompt: p,
          name: (nameEl && nameEl.value || "").trim(),
          sketch: window.EGSketchUrl ? window.EGSketchUrl() : null,
          engine: (document.getElementById("d-engine") || {}).value || "sd35",
          byok: window.EGOwnKey ? window.EGOwnKey() : null
        })
      });
      const data = await res.json().catch(() => ({}));

      /* The quick routes were unavailable and the picture is being drawn on
         the order's own GPU: wait on it the way a clip is waited on. */
      if (res.ok && data.id && data.status === "queued") {
        bar.stop();
        if (window.EGJobWatch) { window.EGJobWatch(card, data.id, p, data); return; }
      }

      bar.done();
      bar.stop();
      card.classList.remove("is-working");

      if (!res.ok || !data.url) {
        card.classList.add("is-error");
        card.innerHTML =
          "<p>" + esc(data.error || "The drawing failed. Try again, or change the wording.") + "</p>" +
          '<figcaption>' + esc(p) + "</figcaption>";
      } else {
        card.innerHTML =
          '<a href="' + esc(data.url) + '" target="_blank" rel="noopener">' +
          '<img src="' + esc(data.url) + '" alt="' + esc(p) + '" loading="lazy"></a>' +
          "<figcaption>" + esc(p) +
          '<span class="draw-meta">Generated, not photographed' +
          (data.provider ? " \u00b7 " + esc(data.provider) : "") +
          (data.hardware ? '<br>Drawn on ' + esc(data.hardware) : "") +
          (data.sketch === true ? '<br>Followed your sketch' : "") +
          (data.note ? '<br>' + esc(data.note) : "") +
          " \u00b7 open in a new tab for the full size</span></figcaption>";
        if (window.EGMontageAdd) window.EGMontageAdd(data.url, p, "image");
        if (window.EGFileButton) window.EGFileButton(card, data.url, p, "image");
        if (window.EGArrived) window.EGArrived("image", card);
      }
    } catch {
      bar.stop();
      card.classList.remove("is-working");
      card.classList.add("is-error");
      card.innerHTML =
        "<p>No image could be fetched \u2014 this page may be running without its backend.</p>" +
        '<figcaption>' + esc(p) + "</figcaption>";
    } finally {
      busy = false;
      btn.disabled = false;
      btn.textContent = label;
    }
  };

  form.addEventListener("submit", (e) => { e.preventDefault(); draw(box.value); });

  box.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      form.requestSubmit ? form.requestSubmit() : draw(box.value);
    }
  });

  if (examples) examples.addEventListener("click", (e) => {
    const b = e.target.closest(".chip");
    if (!b) return;
    box.value = b.textContent.trim();
    box.focus();
  });

  if (clear) clear.addEventListener("click", () => {
    out.innerHTML = "";
    clear.hidden = true;
    box.value = "";
    box.focus();
  });
})();

/* ----------------------------------------------------------- Sketch it first
   An eight-hundred-pixel square to plan a picture in before the model draws
   it. Freehand or straight lines, a few shapes, ten colours, three pen
   widths, undo and clear. When it is handed over, the sketch is uploaded
   like any other attachment and the drawing route uses it as the starting
   frame — so what comes back follows the arrangement you put down rather
   than only the words. */
(() => {
  "use strict";
  const pad = document.getElementById("sketch-pad");
  const canvas = document.getElementById("sketch-canvas");
  const open = document.getElementById("d-sketch-open");
  if (!pad || !canvas || !open) return;

  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  const msg = document.getElementById("sk-msg");
  const prompt = document.getElementById("d-prompt");
  const PAPER = "#fdfbf5";

  let tool = "free", colour = "#1b1b1f", size = 4, fill = false;
  let nib = "round", alpha = 1, transparent = false;
  let drawing = false, startX = 0, startY = 0, snapshot = null;
  let lastX = 0, lastY = 0, travel = 0;
  /* A selection is either a rectangle or a freehand loop. Once something is
     done to it — dragged, rotated, mirrored, pasted — it is lifted off the
     paper into a float that hovers until it is put down. */
  let sel = null;            // { x, y, w, h, pts|null }
  let float_ = null;         // { cv, x, y, w, h, angle, dragging, ox, oy }
  let clip = null;           // the pad's own clipboard, a canvas
  const overlay = document.getElementById("sketch-overlay");
  const octx = overlay ? overlay.getContext("2d") : null;
  /* A piece carried in from the Turning Shop, waiting to be put down. */
  let placing = null;   // { img, scale, under }
  const history = [];

  const blank = () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!transparent) {
      ctx.fillStyle = PAPER;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
  };
  blank();

  const remember = () => {
    try { history.push(ctx.getImageData(0, 0, canvas.width, canvas.height)); } catch { /* tainted */ }
    if (history.length > 24) history.shift();
  };

  /* The canvas is 800 square whatever size it is shown at. */
  const at = (e) => {
    const r = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - r.left) * (canvas.width / r.width),
      y: (e.clientY - r.top) * (canvas.height / r.height)
    };
  };

  const pen = () => {
    const flatNib = nib === "flat" || nib === "chisel" || nib === "dashed";
    ctx.lineCap = flatNib ? "butt" : "round";
    ctx.lineJoin = flatNib ? "miter" : "round";
    ctx.lineWidth = size;
    ctx.globalAlpha = alpha;
    ctx.setLineDash(nib === "dashed" ? [size * 2.2, size * 1.8]
      : nib === "dotted" ? [0.1, size * 1.9] : []);
    if (nib === "dotted") ctx.lineCap = "round";
    /* On transparent paper the rubber takes pixels away rather than
       painting them the colour of a page that is not there. */
    ctx.globalCompositeOperation =
      (tool === "erase" && transparent) ? "destination-out"
        : (nib === "marker" ? "multiply" : "source-over");
    ctx.strokeStyle = tool === "erase" ? PAPER : colour;
    ctx.fillStyle = tool === "erase" ? PAPER : colour;
    if (nib === "marker") ctx.globalAlpha = Math.min(alpha, 0.38);
    if (nib === "neon") { ctx.shadowColor = colour; ctx.shadowBlur = size * 1.6; }
    else { ctx.shadowBlur = 0; ctx.shadowColor = "transparent"; }
  };

  const restore = () => {
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.setLineDash([]);
    ctx.shadowBlur = 0;
    ctx.shadowColor = "transparent";
  };

  /* ---- the nibs ---------------------------------------------------------
     Every one of these is drawn segment by segment between the last pointer
     position and this one, which is what lets a nib have an angle, a grain
     or a spray rather than being a uniform tube. */
  const rnd = (n) => (Math.random() - 0.5) * 2 * n;

  function strokeSeg(x0, y0, x1, y1) {
    const dx = x1 - x0, dy = y1 - y0;
    const len = Math.hypot(dx, dy) || 0.01;
    pen();
    if (nib === "airbrush" || nib === "spatter" || nib === "sprayline") {
      const dots = nib === "spatter" ? 14 : nib === "sprayline" ? 6 : 26;
      const spread = size * (nib === "spatter" ? 1.5 : 0.75);
      ctx.globalAlpha = alpha * (nib === "airbrush" ? 0.1 : 0.5);
      for (let i = 0; i < dots; i++) {
        const t = Math.random();
        const px = x0 + dx * t + rnd(spread);
        const py = y0 + dy * t + rnd(spread);
        const r = nib === "spatter" ? Math.random() * size * 0.35 + 0.4 : Math.max(0.4, size * 0.09);
        ctx.beginPath();
        ctx.arc(px, py, r, 0, Math.PI * 2);
        ctx.fill();
      }
      restore();
      return;
    }
    if (nib === "calligraphy" || nib === "chisel" || nib === "flat") {
      /* A fixed-angle nib: the stroke is a quadrilateral swept between the
         two ends, so it is broad across the angle and thin along it. */
      const ang = nib === "calligraphy" ? -Math.PI / 4 : nib === "chisel" ? 0 : Math.PI / 2;
      const hx = Math.cos(ang) * size / 2, hy = Math.sin(ang) * size / 2;
      ctx.beginPath();
      ctx.moveTo(x0 - hx, y0 - hy);
      ctx.lineTo(x0 + hx, y0 + hy);
      ctx.lineTo(x1 + hx, y1 + hy);
      ctx.lineTo(x1 - hx, y1 - hy);
      ctx.closePath();
      ctx.fill();
      restore();
      return;
    }
    if (nib === "ribbon") {
      /* Width follows speed, the way a loaded brush thins as it is dragged. */
      const w = Math.max(1, size * Math.max(0.18, 1 - len / 48));
      ctx.lineWidth = w;
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      restore();
      return;
    }
    if (nib === "pencil" || nib === "charcoal" || nib === "crayon") {
      const passes = nib === "charcoal" ? 5 : nib === "crayon" ? 4 : 3;
      const jitter = nib === "pencil" ? size * 0.22 : size * 0.5;
      ctx.lineWidth = Math.max(0.6, size * (nib === "pencil" ? 0.5 : 0.7));
      for (let i = 0; i < passes; i++) {
        if (nib === "crayon" && Math.random() < 0.25) continue;   // waxy skips
        ctx.globalAlpha = alpha * (nib === "pencil" ? 0.33 : 0.26);
        ctx.beginPath();
        ctx.moveTo(x0 + rnd(jitter), y0 + rnd(jitter));
        ctx.lineTo(x1 + rnd(jitter), y1 + rnd(jitter));
        ctx.stroke();
      }
      restore();
      return;
    }
    if (nib === "bristle") {
      const hairs = Math.max(3, Math.round(size / 3));
      const nx = -dy / len, ny = dx / len;
      ctx.lineWidth = Math.max(0.6, size / hairs);
      for (let i = 0; i < hairs; i++) {
        const off = (i / (hairs - 1) - 0.5) * size;
        ctx.globalAlpha = alpha * (0.35 + Math.random() * 0.4);
        ctx.beginPath();
        ctx.moveTo(x0 + nx * off, y0 + ny * off);
        ctx.lineTo(x1 + nx * off, y1 + ny * off);
        ctx.stroke();
      }
      restore();
      return;
    }
    if (nib === "double") {
      const nx = -dy / len, ny = dx / len, off = size * 0.6;
      ctx.lineWidth = Math.max(1, size * 0.3);
      for (const k of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(x0 + nx * off * k, y0 + ny * off * k);
        ctx.lineTo(x1 + nx * off * k, y1 + ny * off * k);
        ctx.stroke();
      }
      restore();
      return;
    }
    if (nib === "hatch") {
      const nx = -dy / len, ny = dx / len;
      ctx.lineWidth = Math.max(0.6, size * 0.14);
      ctx.globalAlpha = alpha * 0.8;
      for (let t = 0; t < len; t += Math.max(2, size * 0.45)) {
        const px = x0 + dx * (t / len), py = y0 + dy * (t / len);
        ctx.beginPath();
        ctx.moveTo(px - nx * size / 2 - dx / len * size / 2, py - ny * size / 2 - dy / len * size / 2);
        ctx.lineTo(px + nx * size / 2 + dx / len * size / 2, py + ny * size / 2 + dy / len * size / 2);
        ctx.stroke();
      }
      restore();
      return;
    }
    /* round, marker, neon, dotted, dashed and the eraser all draw a plain
       stroke; the differences are in pen(). */
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
    restore();
  }

  const shape = (x, y) => {
    if (snapshot) ctx.putImageData(snapshot, 0, 0);
    pen();
    ctx.beginPath();
    if (tool === "line") {
      ctx.moveTo(startX, startY); ctx.lineTo(x, y);
    } else if (tool === "rect") {
      ctx.rect(Math.min(startX, x), Math.min(startY, y), Math.abs(x - startX), Math.abs(y - startY));
    } else if (tool === "ellipse") {
      ctx.ellipse((startX + x) / 2, (startY + y) / 2,
        Math.abs(x - startX) / 2, Math.abs(y - startY) / 2, 0, 0, Math.PI * 2);
    } else if (tool === "triangle") {
      ctx.moveTo((startX + x) / 2, startY);
      ctx.lineTo(x, y);
      ctx.lineTo(startX, y);
      ctx.closePath();
    }
    if (fill && tool !== "line") ctx.fill(); else ctx.stroke();
    restore();
  };

  /* --- fill an area ---------------------------------------------------
     A flood fill from the point clicked, spreading through everything that
     matches the colour under the cursor within a small tolerance, so an
     outline drawn with a soft edge still holds the paint in. Scanline
     spans rather than a pixel queue, because 640,000 pixels is enough to
     notice the difference. */
  const near = (d, i, r, g, b, tol) =>
    Math.abs(d[i] - r) <= tol && Math.abs(d[i + 1] - g) <= tol &&
    Math.abs(d[i + 2] - b) <= tol && Math.abs(d[i + 3] - 255) <= tol;

  function flood(sx, sy, hex) {
    const w = canvas.width, h = canvas.height;
    sx = Math.round(sx); sy = Math.round(sy);
    if (sx < 0 || sy < 0 || sx >= w || sy >= h) return;
    const img = ctx.getImageData(0, 0, w, h);
    const d = img.data;
    const at0 = (sy * w + sx) * 4;
    const sr = d[at0], sg = d[at0 + 1], sb = d[at0 + 2];

    const t = document.createElement("canvas");
    t.width = t.height = 1;
    const tc = t.getContext("2d");
    tc.fillStyle = hex;
    tc.fillRect(0, 0, 1, 1);
    const [fr, fg, fb] = tc.getImageData(0, 0, 1, 1).data;
    if (Math.abs(sr - fr) < 3 && Math.abs(sg - fg) < 3 && Math.abs(sb - fb) < 3) return;

    const tol = 32;
    const seen = new Uint8Array(w * h);
    const stack = [[sx, sy]];
    while (stack.length) {
      const [px, py] = stack.pop();
      let x0 = px;
      while (x0 >= 0 && !seen[py * w + x0] && near(d, (py * w + x0) * 4, sr, sg, sb, tol)) x0--;
      x0++;
      let up = false, down = false;
      for (let x = x0; x < w && !seen[py * w + x] && near(d, (py * w + x) * 4, sr, sg, sb, tol); x++) {
        const i = (py * w + x) * 4;
        d[i] = fr; d[i + 1] = fg; d[i + 2] = fb; d[i + 3] = 255;
        seen[py * w + x] = 1;
        if (py > 0) {
          const ok = !seen[(py - 1) * w + x] && near(d, ((py - 1) * w + x) * 4, sr, sg, sb, tol);
          if (ok && !up) { stack.push([x, py - 1]); up = true; } else if (!ok) up = false;
        }
        if (py < h - 1) {
          const ok = !seen[(py + 1) * w + x] && near(d, ((py + 1) * w + x) * 4, sr, sg, sb, tol);
          if (ok && !down) { stack.push([x, py + 1]); down = true; } else if (!ok) down = false;
        }
      }
    }
    ctx.putImageData(img, 0, 0);
  }

  /* ---- selection, and the float -----------------------------------------
     A selection is a boundary. The moment it is acted upon the pixels are
     lifted into a float — its own little canvas — which hovers above the
     paper and can be dragged, scrolled bigger, rotated and mirrored before
     it is put down again. Nothing is committed until it is. */
  const clearOverlay = () => { if (octx) octx.clearRect(0, 0, overlay.width, overlay.height); };

  function paintOverlay() {
    if (!octx) return;
    clearOverlay();
    if (float_) {
      octx.save();
      octx.translate(float_.x + float_.w / 2, float_.y + float_.h / 2);
      octx.rotate(float_.angle * Math.PI / 180);
      octx.globalAlpha = 0.92;
      octx.drawImage(float_.cv, -float_.w / 2, -float_.h / 2, float_.w, float_.h);
      octx.globalAlpha = 1;
      octx.strokeStyle = "rgba(215,176,90,0.95)";
      octx.lineWidth = 2;
      octx.setLineDash([7, 5]);
      octx.strokeRect(-float_.w / 2, -float_.h / 2, float_.w, float_.h);
      octx.restore();
      return;
    }
    if (sel) {
      octx.strokeStyle = "rgba(215,176,90,0.95)";
      octx.lineWidth = 2;
      octx.setLineDash([7, 5]);
      if (sel.pts && sel.pts.length > 2) {
        octx.beginPath();
        octx.moveTo(sel.pts[0][0], sel.pts[0][1]);
        for (const q of sel.pts.slice(1)) octx.lineTo(q[0], q[1]);
        octx.closePath();
        octx.stroke();
      } else {
        octx.strokeRect(sel.x, sel.y, sel.w, sel.h);
      }
    }
  }

  /* Cut the selected pixels out onto their own canvas. */
  function liftSelection(cut) {
    if (!sel || sel.w < 2 || sel.h < 2) return null;
    const cv = document.createElement("canvas");
    cv.width = Math.round(sel.w); cv.height = Math.round(sel.h);
    const c2 = cv.getContext("2d");
    c2.drawImage(canvas, sel.x, sel.y, sel.w, sel.h, 0, 0, cv.width, cv.height);
    if (sel.pts && sel.pts.length > 2) {
      /* A freehand loop: keep only what falls inside the drawn path. */
      c2.globalCompositeOperation = "destination-in";
      c2.beginPath();
      c2.moveTo(sel.pts[0][0] - sel.x, sel.pts[0][1] - sel.y);
      for (const q of sel.pts.slice(1)) c2.lineTo(q[0] - sel.x, q[1] - sel.y);
      c2.closePath();
      c2.fill();
      c2.globalCompositeOperation = "source-over";
    }
    if (cut) {
      remember();
      ctx.save();
      if (sel.pts && sel.pts.length > 2) {
        ctx.beginPath();
        ctx.moveTo(sel.pts[0][0], sel.pts[0][1]);
        for (const q of sel.pts.slice(1)) ctx.lineTo(q[0], q[1]);
        ctx.closePath();
        ctx.clip();
      }
      if (transparent) ctx.clearRect(sel.x, sel.y, sel.w, sel.h);
      else { ctx.fillStyle = PAPER; ctx.fillRect(sel.x, sel.y, sel.w, sel.h); }
      ctx.restore();
    }
    return cv;
  }

  function toFloat(cv, x, y, w, h) {
    float_ = {
      cv, x, y,
      w: w || cv.width, h: h || cv.height,
      angle: 0, dragging: false, ox: 0, oy: 0
    };
    pad.classList.add("has-float");
    paintOverlay();
    say("The selection is floating \u2014 drag it, scroll to size it, rotate or mirror it, " +
      "then press Put it down (or Enter).");
  }

  function dropFloat() {
    if (!float_) return;
    remember();
    ctx.save();
    ctx.translate(float_.x + float_.w / 2, float_.y + float_.h / 2);
    ctx.rotate(float_.angle * Math.PI / 180);
    ctx.drawImage(float_.cv, -float_.w / 2, -float_.h / 2, float_.w, float_.h);
    ctx.restore();
    float_ = null;
    sel = null;
    pad.classList.remove("has-float");
    clearOverlay();
    mark(false);
    say("Put down.");
  }

  const inFloat = (p) => Boolean(float_) &&
    p.x >= float_.x && p.x <= float_.x + float_.w &&
    p.y >= float_.y && p.y <= float_.y + float_.h;

  canvas.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    canvas.setPointerCapture(e.pointerId);
    const p = at(e);
    if (placing) { stamp(p.x, p.y); return; }

    if (float_) {
      if (inFloat(p)) {
        float_.dragging = true;
        float_.ox = p.x - float_.x;
        float_.oy = p.y - float_.y;
        return;
      }
      dropFloat();
      return;
    }

    if (tool === "select" || tool === "lasso") {
      drawing = true;
      startX = p.x; startY = p.y;
      sel = tool === "lasso"
        ? { x: p.x, y: p.y, w: 0, h: 0, pts: [[p.x, p.y]] }
        : { x: p.x, y: p.y, w: 0, h: 0, pts: null };
      paintOverlay();
      return;
    }

    sel = null;
    clearOverlay();

    if (tool === "fill") {
      remember();
      flood(p.x, p.y, colour);
      mark(false);
      return;
    }
    drawing = true; startX = p.x; startY = p.y;
    lastX = p.x; lastY = p.y; travel = 0;
    remember();
    if (tool === "free" || tool === "erase") {
      strokeSeg(p.x, p.y, p.x + 0.01, p.y);
    } else {
      try { snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height); } catch { snapshot = null; }
    }
  });

  canvas.addEventListener("pointermove", (e) => {
    if (placing) { ghost(at(e)); return; }
    const p = at(e);
    if (float_ && float_.dragging) {
      float_.x = p.x - float_.ox;
      float_.y = p.y - float_.oy;
      paintOverlay();
      return;
    }
    if (!drawing) return;
    if (tool === "select" || tool === "lasso") {
      if (sel && sel.pts) {
        sel.pts.push([p.x, p.y]);
        const xs = sel.pts.map((q) => q[0]), ys = sel.pts.map((q) => q[1]);
        sel.x = Math.min.apply(null, xs); sel.y = Math.min.apply(null, ys);
        sel.w = Math.max.apply(null, xs) - sel.x;
        sel.h = Math.max.apply(null, ys) - sel.y;
      } else if (sel) {
        sel.x = Math.min(startX, p.x); sel.y = Math.min(startY, p.y);
        sel.w = Math.abs(p.x - startX); sel.h = Math.abs(p.y - startY);
      }
      paintOverlay();
      return;
    }
    if (tool === "free" || tool === "erase") {
      strokeSeg(lastX, lastY, p.x, p.y);
      lastX = p.x; lastY = p.y;
    } else shape(p.x, p.y);
  });

  const finish = (e) => {
    if (float_ && float_.dragging) { float_.dragging = false; return; }
    if (!drawing) return;
    drawing = false;
    if (tool === "select" || tool === "lasso") {
      if (!sel || sel.w < 3 || sel.h < 3) { sel = null; clearOverlay(); }
      else say("Selected. Copy it, crop to it, rotate or mirror it, or drag it to move it.");
      paintOverlay();
      return;
    }
    if (tool !== "free" && tool !== "erase") shape(at(e).x, at(e).y);
    snapshot = null;
    mark(false);
  };
  canvas.addEventListener("pointerup", finish);
  canvas.addEventListener("pointercancel", finish);
  canvas.addEventListener("pointerleave", (e) => { if (drawing) finish(e); });

  /* --- the tool bar --- */
  /* Ten quick swatches, and behind them the whole wheel: any of the
     sixteen million, by picker or by hex. */
  const rgb = document.getElementById("sk-rgb");
  const hex = document.getElementById("sk-hex");

  const setColour = (value, from) => {
    const v = String(value || "").trim();
    if (!/^#[0-9a-f]{6}$/i.test(v)) return;
    colour = v.toLowerCase();
    if (rgb && from !== "wheel") rgb.value = colour;
    if (hex && from !== "hex") hex.value = colour;
    pad.querySelectorAll(".swatch").forEach((o) =>
      o.classList.toggle("is-on", String(o.dataset.colour).toLowerCase() === colour));
    pad.style.setProperty("--ink", colour);
    if (tool === "erase") setTool("free");
  };

  pad.querySelectorAll(".swatch").forEach((b) => {
    b.style.background = b.dataset.colour;
    b.addEventListener("click", () => setColour(b.dataset.colour));
  });
  if (rgb) rgb.addEventListener("input", () => setColour(rgb.value, "wheel"));
  if (hex) hex.addEventListener("change", () => setColour(hex.value, "hex"));

  const setTool = (name) => {
    tool = name;
    pad.querySelectorAll("[data-tool]").forEach((o) =>
      o.classList.toggle("is-on", o.dataset.tool === name));
  };
  pad.querySelectorAll("[data-tool]").forEach((b) =>
    b.addEventListener("click", () => setTool(b.dataset.tool)));

  /* One nib, dragged from a hair to a house-painter's brush. */
  const sizeEl = document.getElementById("sk-size");
  const sizeOut = document.getElementById("sk-size-out");
  if (sizeEl) {
    const setSize = () => {
      size = Number(sizeEl.value) || 1;
      if (sizeOut) sizeOut.textContent = String(size);
      pad.style.setProperty("--nib", Math.max(4, Math.min(44, size)) + "px");
    };
    sizeEl.addEventListener("input", setSize);
    setSize();
  }

  const solidBtn = document.getElementById("sk-solid");
  if (solidBtn) solidBtn.addEventListener("click", () => {
    fill = !fill;
    solidBtn.classList.toggle("is-on", fill);
    solidBtn.setAttribute("aria-pressed", String(fill));
  });

  const nibEl = document.getElementById("sk-nib");
  if (nibEl) nibEl.addEventListener("change", () => { nib = nibEl.value || "round"; });

  const alphaEl = document.getElementById("sk-alpha");
  const alphaOut = document.getElementById("sk-alpha-out");
  if (alphaEl) {
    const setAlpha = () => {
      alpha = Math.max(0.05, Math.min(1, Number(alphaEl.value) / 100));
      if (alphaOut) alphaOut.textContent = Math.round(alpha * 100) + "%";
    };
    alphaEl.addEventListener("input", setAlpha);
    setAlpha();
  }

  /* Clear paper or white paper. On clear paper the rubber takes pixels
     away, and what is handed over keeps its transparency. */
  const paperBtn = document.getElementById("sk-paper");
  if (paperBtn) paperBtn.addEventListener("click", () => {
    transparent = !transparent;
    paperBtn.classList.toggle("is-on", transparent);
    paperBtn.setAttribute("aria-pressed", String(transparent));
    pad.classList.toggle("is-transparent", transparent);
    remember();
    if (transparent) {
      /* Lift the white page away and keep the marks: anything still the
         colour of the paper becomes nothing. */
      try {
        const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const d = img.data;
        for (let i = 0; i < d.length; i += 4) {
          if (d[i] > 246 && d[i + 1] > 243 && d[i + 2] > 235) d[i + 3] = 0;
        }
        ctx.putImageData(img, 0, 0);
      } catch { /* tainted */ }
    } else {
      /* Put the page back underneath what is drawn. */
      const keep = document.createElement("canvas");
      keep.width = canvas.width; keep.height = canvas.height;
      keep.getContext("2d").drawImage(canvas, 0, 0);
      ctx.save();
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = PAPER;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(keep, 0, 0);
      ctx.restore();
    }
    mark(false);
    say(transparent ? "The paper is clear now." : "The paper is solid again.");
  });

  /* ---- copy, paste, crop, rotate, mirror ---- */
  const copyToClipboard = async (cv) => {
    clip = cv;
    try {
      if (navigator.clipboard && window.ClipboardItem && cv.toBlob) {
        const blob = await new Promise((ok) => cv.toBlob(ok, "image/png"));
        if (blob) await navigator.clipboard.write([new window.ClipboardItem({ "image/png": blob })]);
        return true;
      }
    } catch { /* the browser said no; the pad keeps its own copy */ }
    return false;
  };

  const copySel = document.getElementById("sk-copy");
  if (copySel) copySel.addEventListener("click", async () => {
    const cv = float_ ? float_.cv : liftSelection(false);
    if (!cv) { say("Select something first \u2014 use Select a box or Freehand select.", true); return; }
    const out = await copyToClipboard(cv);
    say(out ? "The selection is on the clipboard." : "Copied, and held here \u2014 this browser would not take it.");
  });

  const copyAll = document.getElementById("sk-copy-all");
  if (copyAll) copyAll.addEventListener("click", async () => {
    const cv = document.createElement("canvas");
    cv.width = canvas.width; cv.height = canvas.height;
    cv.getContext("2d").drawImage(canvas, 0, 0);
    const out = await copyToClipboard(cv);
    say(out ? "The whole sketch is on the clipboard." : "Copied, and held here \u2014 this browser would not take it.");
  });

  const placeImage = (img, w, h) => {
    const cv = document.createElement("canvas");
    cv.width = w; cv.height = h;
    cv.getContext("2d").drawImage(img, 0, 0, w, h);
    const fit = Math.min(1, (canvas.width * 0.7) / w, (canvas.height * 0.7) / h);
    toFloat(cv, (canvas.width - w * fit) / 2, (canvas.height - h * fit) / 2, w * fit, h * fit);
  };

  async function pasteIn() {
    /* The system clipboard first, the pad's own second. */
    try {
      if (navigator.clipboard && navigator.clipboard.read) {
        const items = await navigator.clipboard.read();
        for (const item of items) {
          const type = item.types.find((t) => /^image\//.test(t));
          if (!type) continue;
          const blob = await item.getType(type);
          const bmp = await createImageBitmap(blob);
          placeImage(bmp, bmp.width, bmp.height);
          return;
        }
      }
    } catch { /* no permission, or nothing in it */ }
    if (clip) { placeImage(clip, clip.width, clip.height); return; }
    say("There is no picture on the clipboard. Copy something first, or allow this page to read it.", true);
  }
  const pasteBtn = document.getElementById("sk-paste");
  if (pasteBtn) pasteBtn.addEventListener("click", pasteIn);
  window.addEventListener("paste", (e) => {
    if (pad.hidden) return;
    const f = e.clipboardData && e.clipboardData.files && e.clipboardData.files[0];
    if (!f || !/^image\//.test(f.type)) return;
    e.preventDefault();
    const img = new Image();
    img.onload = () => placeImage(img, img.width, img.height);
    img.src = URL.createObjectURL(f);
  });

  const cropBtn = document.getElementById("sk-crop");
  if (cropBtn) cropBtn.addEventListener("click", () => {
    const cv = liftSelection(false);
    if (!cv) { say("Select the part you want to keep first.", true); return; }
    remember();
    blank();
    const fit = Math.min(canvas.width / cv.width, canvas.height / cv.height);
    const w = cv.width * fit, h = cv.height * fit;
    ctx.drawImage(cv, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
    sel = null; clearOverlay(); mark(false);
    say("Cropped to the selection, and filled out to the square.");
  });

  const needFloat = () => {
    if (float_) return true;
    const cv = liftSelection(true);
    if (!cv) { say("Select something first.", true); return false; }
    toFloat(cv, sel.x, sel.y, sel.w, sel.h);
    return true;
  };

  const angleEl = document.getElementById("sk-angle");
  const angleOut = document.getElementById("sk-angle-out");
  const showAngle = () => {
    if (angleEl && float_) angleEl.value = String(Math.round(float_.angle));
    if (angleOut && float_) angleOut.textContent = Math.round(float_.angle) + "\u00b0";
  };
  const turn = (deg) => {
    if (!needFloat()) return;
    float_.angle = ((float_.angle + deg + 180) % 360) - 180;
    showAngle();
    paintOverlay();
  };
  const rotL = document.getElementById("sk-rot-l");
  const rotR = document.getElementById("sk-rot-r");
  if (rotL) rotL.addEventListener("click", () => turn(-90));
  if (rotR) rotR.addEventListener("click", () => turn(90));
  if (angleEl) angleEl.addEventListener("input", () => {
    if (!needFloat()) return;
    float_.angle = Number(angleEl.value) || 0;
    if (angleOut) angleOut.textContent = Math.round(float_.angle) + "\u00b0";
    paintOverlay();
  });

  /* Across, down, and about the diagonal — which is a transpose, not a
     flip, so a tall selection comes back wide. */
  const mirror = (how) => {
    if (!needFloat()) return;
    const src = float_.cv;
    const cv = document.createElement("canvas");
    const diag = how === "d" || how === "d2";
    cv.width = diag ? src.height : src.width;
    cv.height = diag ? src.width : src.height;
    const c2 = cv.getContext("2d");
    if (how === "h") { c2.translate(cv.width, 0); c2.scale(-1, 1); }
    else if (how === "v") { c2.translate(0, cv.height); c2.scale(1, -1); }
    else { c2.rotate(Math.PI / 2); c2.scale(1, -1); }   // transpose
    c2.drawImage(src, 0, 0);
    const w = float_.w, h = float_.h;
    float_.cv = cv;
    if (diag) { float_.w = h; float_.h = w; }
    paintOverlay();
    say("Mirrored.");
  };
  const fh = document.getElementById("sk-flip-h");
  const fv = document.getElementById("sk-flip-v");
  const fd = document.getElementById("sk-flip-d");
  if (fh) fh.addEventListener("click", () => mirror("h"));
  if (fv) fv.addEventListener("click", () => mirror("v"));
  if (fd) fd.addEventListener("click", () => mirror("d"));

  const dropBtn = document.getElementById("sk-drop");
  if (dropBtn) dropBtn.addEventListener("click", dropFloat);

  window.addEventListener("keydown", (e) => {
    if (pad.hidden) return;
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || "");
    if (e.key === "Enter" && float_) { e.preventDefault(); dropFloat(); return; }
    if (e.key === "Escape" && float_) { float_ = null; pad.classList.remove("has-float"); clearOverlay(); return; }
    if (e.key === "Escape" && sel) { sel = null; clearOverlay(); return; }
    if (typing) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "c" && (sel || float_)) {
      e.preventDefault();
      const cv = float_ ? float_.cv : liftSelection(false);
      if (cv) copyToClipboard(cv);
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") { e.preventDefault(); pasteIn(); }
  });

  const undo = document.getElementById("sk-undo");
  if (undo) undo.addEventListener("click", () => {
    const prev = history.pop();
    if (prev) ctx.putImageData(prev, 0, 0);
    mark(false);
  });

  const wipe = document.getElementById("sk-clear");
  if (wipe) wipe.addEventListener("click", () => { remember(); blank(); mark(false); });

  /* --- handing it over --- */
  let attached = null;           // { url, name }
  const say = (t, bad) => { if (msg) { msg.textContent = t || ""; msg.className = "auth-msg" + (bad ? " is-bad" : ""); } };

  const mark = (on) => {
    pad.classList.toggle("is-attached", Boolean(on));
    open.classList.toggle("has-sketch", Boolean(on));
    open.textContent = on ? "Sketch attached" : "Sketch it first";
    if (!on && attached) { attached = null; say("The sketch changed \u2014 hand it over again when you are ready."); }
    window.EGSketch = on ? attached : null;
  };

  const use = document.getElementById("sk-use");
  if (use) use.addEventListener("click", async () => {
    if (float_) dropFloat();
    use.disabled = true;
    const job = window.EGWork ? window.EGWork.start("the sketch is being handed over") : null;
    say("Handing the sketch over\u2026");
    try {
      const data = canvas.toDataURL("image/png").split(",")[1];
      const res = await fetch("/api/upload", {
        method: "POST",
        headers: window.EGAuthHeaders ? window.EGAuthHeaders() : { "content-type": "application/json" },
        body: JSON.stringify({ name: "sketch.png", type: "image/png", data, asker: "sketch" })
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok || !out.url) throw new Error(out.error || "the upload was refused");
      attached = { url: out.url, name: out.name || "sketch.png" };
      mark(true);
      say("Sketch attached. Write what it should become, then press Generate.");
      if (prompt) prompt.focus();
    } catch (err) {
      say("The sketch could not be handed over: " + ((err && err.message) || "unknown error"), true);
    } finally {
      if (window.EGWork) window.EGWork.end(job);
      use.disabled = false;
    }
  });

  const shut = document.getElementById("sk-close");
  const toggle = (on) => {
    pad.hidden = !on;
    open.setAttribute("aria-expanded", String(on));
    if (on) setTimeout(() => pad.scrollIntoView({ block: "center", behavior: "smooth" }), 60);
  };
  open.addEventListener("click", () => toggle(pad.hidden));
  if (shut) shut.addEventListener("click", () => toggle(false));

  /* The drawing code asks for this when it submits. */
  window.EGSketchUrl = () => (attached ? attached.url : null);

  /* --- putting a model down on the paper -----------------------------------
     The Turning Shop can send a cut-out of whatever is on the bench straight
     here. It does not land anywhere until you say where: the pad opens, the
     piece follows the cursor as a ghost, the wheel sizes it, and the next
     click prints it onto the paper. Escape puts it back in the drawer. */
  function ghost(p) {
    if (!placing) return;
    if (placing.under) ctx.putImageData(placing.under, 0, 0);
    const w = placing.img.width * placing.scale;
    const h = placing.img.height * placing.scale;
    ctx.save();
    ctx.globalAlpha = 0.65;
    ctx.drawImage(placing.img, p.x - w / 2, p.y - h / 2, w, h);
    ctx.restore();
  }

  function stamp(x, y) {
    if (!placing) return;
    if (placing.under) ctx.putImageData(placing.under, 0, 0);
    remember();
    const w = placing.img.width * placing.scale;
    const h = placing.img.height * placing.scale;
    ctx.drawImage(placing.img, x - w / 2, y - h / 2, w, h);
    placing = null;
    pad.classList.remove("is-placing");
    mark(false);
    say("The piece is down. Draw round it, put another one down, or press Use this sketch.");
  }

  function dropPlacing() {
    if (!placing) return;
    if (placing.under) ctx.putImageData(placing.under, 0, 0);
    placing = null;
    pad.classList.remove("is-placing");
    say("The piece was put back in the drawer.");
  }

  canvas.addEventListener("wheel", (e) => {
    if (float_) {
      e.preventDefault();
      const k = e.deltaY > 0 ? 0.93 : 1.075;
      const cx = float_.x + float_.w / 2, cy = float_.y + float_.h / 2;
      float_.w = Math.max(8, Math.min(canvas.width * 3, float_.w * k));
      float_.h = Math.max(8, Math.min(canvas.height * 3, float_.h * k));
      float_.x = cx - float_.w / 2;
      float_.y = cy - float_.h / 2;
      paintOverlay();
      return;
    }
    if (!placing) return;
    e.preventDefault();
    placing.scale = Math.max(0.05, Math.min(3, placing.scale * (e.deltaY > 0 ? 0.92 : 1.09)));
  }, { passive: false });
  canvas.addEventListener("pointerleave", () => {
    if (placing && placing.under) ctx.putImageData(placing.under, 0, 0);
  });
  window.addEventListener("keydown", (e) => { if (e.key === "Escape") dropPlacing(); });

  /* Called by the Turning Shop: a transparent cut-out of the bench. */
  /* A scan arrives from the camera as a cut-out with a transparent
     background. It is put straight into the float, which is the pad's
     movable selection: drag it, scroll to size it, turn or mirror it, and
     press Enter when it belongs where it is. */
  window.EGSketchFloat = (url) => {
    const img = new Image();
    if (!/^data:/.test(String(url))) img.crossOrigin = "anonymous";
    img.onload = () => {
      toggle(true);
      const fit = Math.min((canvas.width * 0.55) / img.width,
        (canvas.height * 0.55) / img.height, 2);
      const w = Math.max(16, img.width * fit), h = Math.max(16, img.height * fit);
      const cv = document.createElement("canvas");
      cv.width = img.width; cv.height = img.height;
      cv.getContext("2d").drawImage(img, 0, 0);
      toFloat(cv, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
      const room = document.getElementById("draw-box");
      if (room) room.scrollIntoView({ block: "start", behavior: "smooth" });
      pad.scrollIntoView({ block: "center", behavior: "smooth" });
      canvas.focus();
      say("The scan is on the paper and held \u2014 drag it where you want it, scroll to size it, " +
        "Enter to put it down.");
    };
    img.onerror = () => say("That scan could not be put on the paper.", true);
    img.src = url;
  };

  window.EGModelPlace = (url) => {
    const img = new Image();
    /* A picture handed straight over as data needs no CORS dance; one
       fetched from storage does. */
    if (!/^data:/.test(String(url))) img.crossOrigin = "anonymous";
    img.onload = () => {
      toggle(true);
      const room = document.getElementById("draw-box");
      if (room) room.scrollIntoView({ block: "start", behavior: "smooth" });
      const fit = Math.min(
        (canvas.width * 0.45) / img.width,
        (canvas.height * 0.45) / img.height, 1);
      let under = null;
      try { under = ctx.getImageData(0, 0, canvas.width, canvas.height); } catch { under = null; }
      placing = { img, scale: fit, under };
      pad.classList.add("is-placing");
      say("Click on the paper to put the model down \u2014 move the mouse to aim, " +
        "scroll to size it, Escape to put it back.");
      pad.scrollIntoView({ block: "center", behavior: "smooth" });
      canvas.focus();
    };
    img.onerror = () => say("The view could not be loaded onto the paper.", true);
    img.src = url;
  };

  /* The Turning Shop renders its view and hands it over as a sketch. */
  window.EGModelHandOver = (url) => {
    attached = { url, name: "model.png" };
    mark(true);
    say("A view from the Turning Shop is attached. Say what it is made of, then press Generate.");
    const target = document.getElementById("draw-box");
    if (target) target.scrollIntoView({ block: "start", behavior: "smooth" });
    if (prompt) prompt.focus();
  };
  window.EGSketchClear = () => { attached = null; mark(false); };
})();

/* -------------------------------------------------------- The keeper's key
   A small door for whoever is minding the machines: who asked for what, the
   state of every GPU the order can reach, and a release for the Kaggle lock
   when a job has died without saying so. The key is checked on the server;
   this page only ever learns whether it was right. */
(() => {
  "use strict";
  const open = document.getElementById("kp-open");
  const panel = document.getElementById("keeper-box");
  const form = document.getElementById("keeper-form");
  if (!open || !panel || !form) return;

  const pass = document.getElementById("kp-pass");
  const msg = document.getElementById("kp-msg");
  const out = document.getElementById("kp-out");

  const esc = (s) =>
    String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const say = (t, bad) => {
    msg.textContent = t || "";
    msg.className = "auth-msg" + (bad ? " is-bad" : "");
  };

  open.addEventListener("click", () => {
    panel.hidden = !panel.hidden;
    open.setAttribute("aria-expanded", String(!panel.hidden));
    if (!panel.hidden && pass) pass.focus();
  });

  const ago = (n) => {
    if (n == null) return "";
    if (n < 90) return n + "s ago";
    if (n < 5400) return Math.round(n / 60) + " min ago";
    return Math.round(n / 3600) + " h ago";
  };

  /* The door's own memory of being knocked on. The server is what actually
     counts the tries \u2014 this is only so the page can say how long is left
     without asking, and so the button goes quiet while it is shut. */
  const LOCK = "eg-keeper-shut";
  const shutFor = () => {
    try {
      const until = Number(window.localStorage.getItem(LOCK) || 0);
      const left = until - Date.now();
      return left > 0 ? Math.ceil(left / 60000) : 0;
    } catch { return 0; }
  };
  const shutDown = (mins) => {
    try { window.localStorage.setItem(LOCK, String(Date.now() + mins * 60000)); } catch { /* no store */ }
  };

  const call = async (action, extra) => {
    const left = shutFor();
    if (left > 0) {
      throw new Error("Three wrong keys. This browser cannot try again for " + left +
        (left === 1 ? " more minute." : " more minutes."));
    }
    const res = await fetch("/api/keeper", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(Object.assign({ action, pass: (pass && pass.value) || "" }, extra || {}))
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (data.wait_minutes) shutDown(Number(data.wait_minutes));
      throw new Error(data.error || "the door did not open");
    }
    try { window.localStorage.removeItem(LOCK); } catch { /* no store */ }
    return data;
  };

  const render = (d) => {
    const rows = [];

    rows.push('<h4>The order\u2019s Kaggle GPU</h4>');
    if (d.kaggle && d.kaggle.held) {
      rows.push("<p>Held by a <strong>" + esc(d.kaggle.kind) + "</strong> job since " +
        esc(d.kaggle.since) + " (" + esc(ago(d.kaggle.age_s)) + ")" +
        (d.kaggle.stale ? " \u2014 <strong>this looks stale</strong>" : "") + ".</p>");
      rows.push('<p><button class="btn btn--small" type="button" id="kp-free">' +
        "Free the GPU</button></p>");
    } else {
      rows.push("<p>Free. Nothing is holding the lock.</p>");
    }

    rows.push("<h4>Every machine the order can reach</h4>");
    if (d.gpus && d.gpus.length) {
      rows.push("<table class=\"keeper-table keeper-gpus\"><thead><tr><th>Machine</th><th>Card</th>" +
        "<th>State</th><th>Record</th><th></th></tr></thead><tbody>" +
        d.gpus.map((g) =>
          "<tr><td><strong>" + esc(g.kind) + "</strong> \u00b7 " + esc(g.label) +
          (g.user ? " <span class=\"muted\">(" + esc(g.user) + ")</span>" : "") +
          (g.caps ? "<br><span class=\"muted xsmall\">can do " + esc(g.caps) + "</span>" : "") +
          "</td><td>" + esc(g.gpu || "\u2014") + "</td>" +
          "<td class=\"" + (g.busy ? "is-busy" : "") + "\">" + esc(g.state) +
          (g.stale ? " \u2014 <strong>stale</strong>" : "") +
          (g.last_error ? "<br><span class=\"muted xsmall\">" + esc(g.last_error) + "</span>" : "") +
          "</td><td class=\"muted xsmall\">" +
          (g.successes || g.fails
            ? esc(g.successes || 0) + " done, " + esc(g.fails || 0) + " refused"
            : (g.jobs != null ? esc(g.jobs) + " job(s) taken" : "\u2014")) +
          "</td><td>" +
          (g.can_reset
            ? '<button class="btn btn--small btn--ghost kp-reset" type="button" data-gpu="' +
              esc(g.id) + '" title="' + esc(g.note || "") + '">Reset</button>'
            : "") +
          "</td></tr>").join("") + "</tbody></table>");
      rows.push('<p><button class="btn btn--small btn--ghost" type="button" id="kp-reset-all">' +
        "Reset every machine</button> <span class=\"muted xsmall\">Frees the Kaggle lock, cancels " +
        "anything still marked live, clears the cooldowns and drops every Colab worker so each " +
        "notebook re-registers.</span></p>");
    } else {
      rows.push("<p>No machine answered the census.</p>");
    }

    rows.push("<h4>The Colab pool</h4>");
    if (d.workers && d.workers.length) {
      rows.push("<ul class=\"keeper-list\">" + d.workers.map((w) =>
        "<li><strong>" + esc(w.label) + "</strong> \u00b7 " + esc(w.gpu || "GPU") +
        " \u00b7 " + esc(w.account || "no account given") +
        " \u00b7 can do " + esc(w.caps) +
        " \u00b7 <em>" + esc(w.state) + "</em>, " + esc(w.jobs) + " job(s) taken</li>").join("") + "</ul>");
    } else {
      rows.push("<p>No Colab worker is awake. Open colab/egregora-gpu.ipynb in a Google " +
        "account to add one.</p>");
    }

    rows.push("<h4>Who asked for what</h4>");
    if (d.jobs && d.jobs.length) {
      rows.push("<table class=\"keeper-table\"><thead><tr><th>Who</th><th>Asked for</th>" +
        "<th>Kind</th><th>State</th><th>When</th></tr></thead><tbody>" +
        d.jobs.map((j) =>
          "<tr><td>" + esc(j.who) + "</td><td>" + esc(j.asked) + "</td><td>" + esc(j.kind) +
          "</td><td>" + esc(j.status) + (j.error ? " \u2014 " + esc(j.error) : "") +
          "</td><td>" + esc(ago(j.age_s)) + "</td></tr>").join("") + "</tbody></table>");
    } else {
      rows.push("<p>Nothing has been queued yet.</p>");
    }

    if (d.drawings && d.drawings.length) {
      rows.push("<h4>Quick drawings</h4>");
      rows.push("<table class=\"keeper-table\"><thead><tr><th>Who</th><th>Asked for</th>" +
        "<th>When</th></tr></thead><tbody>" +
        d.drawings.map((j) =>
          "<tr><td>" + esc(j.who) + "</td><td>" + esc(j.asked) + "</td><td>" +
          esc(ago(j.age_s)) + "</td></tr>").join("") + "</tbody></table>");
    }

    out.innerHTML = rows.join("");
    out.hidden = false;

    out.querySelectorAll(".kp-reset").forEach((b) => b.addEventListener("click", async () => {
      const id = b.getAttribute("data-gpu");
      if (!window.confirm("Reset " + id + "? Anything running on it will be abandoned.")) return;
      b.disabled = true;
      try {
        const r = await call("reset", { gpu: id });
        say(r.message || "Reset.");
        render(Object.assign(await call("open"), r.gpus ? { gpus: r.gpus } : {}));
      } catch (err) {
        say((err && err.message) || "It could not be reset.", true);
        b.disabled = false;
      }
    }));

    const all = document.getElementById("kp-reset-all");
    if (all) all.addEventListener("click", async () => {
      if (!window.confirm("Reset every machine the order can reach?")) return;
      all.disabled = true;
      try {
        const r = await call("reset", { gpu: "all" });
        say(r.message || "Reset.");
        render(await call("open"));
      } catch (err) {
        say((err && err.message) || "They could not be reset.", true);
        all.disabled = false;
      }
    });

    const free = document.getElementById("kp-free");
    if (free) free.addEventListener("click", async () => {
      if (!window.confirm("Free the Kaggle GPU? Any job still running on it will be abandoned.")) return;
      free.disabled = true;
      try {
        const r = await call("release");
        say(r.message || "Freed.");
        render(await call("open"));
      } catch (err) {
        say((err && err.message) || "It could not be freed.", true);
        free.disabled = false;
      }
    });
  };

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    say("Trying the key\u2026");
    try {
      const d = await call("open");
      say("Open.");
      render(d);
    } catch (err) {
      out.hidden = true;
      say((err && err.message) || "That is not the key.", true);
    }
  });
})();

/* --------------------------------------------------------------- Filming
   /api/video is a job queue: submit a prompt, then poll until HunyuanVideo
   1.5 has finished the clip (about three minutes for five seconds of 480p). */
(() => {
  "use strict";
  const form = document.getElementById("film-form");
  if (!form) return;

  const box = document.getElementById("v-prompt");
  const aspectEl = document.getElementById("v-aspect");
  const modelEl = document.getElementById("v-model");
  const modelNote = document.getElementById("v-model-note");
  const lengthEl = document.getElementById("v-length");
  const btn = document.getElementById("v-submit");
  const clear = document.getElementById("v-clear");
  const out = document.getElementById("film-out");
  const examples = document.getElementById("film-examples");
  const nameEl = document.getElementById("o-name");
  if (!box || !btn || !out) return;

  /* --- how long a clip may be ---------------------------------------------
     Each model is trained at its own frame rate and its own length, so the
     choices differ: 49 frames of CogVideoX is six seconds, 49 frames of
     HunyuanVideo is two. The list here matches the one the server snaps to,
     in hatchable/lib/videogen.js. */
  const LENGTHS = {
    hunyuan15: { fps: 24, frames: [49, 73, 97, 121, 185, 241], def: 121 },
    wan22: { fps: 16, frames: [33, 49, 65, 81], def: 81 },
    ltx: { fps: 24, frames: [49, 97, 145, 193, 257], def: 97 },
    cogvideox: { fps: 8, frames: [25, 49], def: 49 },
    mochi: { fps: 30, frames: [61, 91, 163], def: 163 }
  };

  const fillLengths = () => {
    if (!lengthEl) return;
    const spec = LENGTHS[(modelEl && modelEl.value) || "hunyuan15"] || LENGTHS.hunyuan15;
    const had = Number(lengthEl.value) || 0;
    lengthEl.innerHTML = "";
    spec.frames.forEach((f) => {
      const secs = Math.round((f / spec.fps) * 10) / 10;
      const o = document.createElement("option");
      o.value = String(f);
      o.textContent = secs + "s \u00b7 " + f + " frames" + (f === spec.def ? " \u00b7 native" : "");
      lengthEl.appendChild(o);
    });
    const keep = spec.frames.indexOf(had) >= 0 ? had : spec.def;
    lengthEl.value = String(keep);
  };
  fillLengths();
  if (modelEl) modelEl.addEventListener("change", fillLengths);

  const esc = (s) =>
    String(s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const ready = (card, data, prompt) => {
    card.classList.remove("is-working");
    var isImage = data.kind === "image";
    card.innerHTML =
      (isImage
        ? '<a href="' + esc(data.url) + '" target="_blank" rel="noopener"><img src="' +
          esc(data.url) + '" alt="' + esc(prompt) + '" loading="lazy"></a>'
        : '<video controls playsinline preload="metadata" src="' + esc(data.url) + '"></video>') +
      "<figcaption>" + esc(prompt) +
      '<span class="draw-meta">Generated, not ' + (isImage ? "photographed" : "filmed") + ' \u00b7 ' +
      esc(data.model || "HunyuanVideo 1.5 \u00b7 480p") +
      (data.hardware ? "<br>Rendered on " + esc(data.hardware) : "") +
      (data.carried ? '<br>Carried over \u00b7 ' + esc(data.carried) : "") +
      "</span></figcaption>";
    const meta = { id: data.id, sheet: data.sheet, seed: data.seed };
    if (window.EGMontageAdd) window.EGMontageAdd(data.url, prompt, isImage ? "image" : "video", meta);
    if (window.EGMontageAdd) {
      const cut = document.createElement("button");
      cut.type = "button";
      cut.className = "btn btn--ghost btn--small card-to-montage";
      const settle = () => {
        const inRoom = window.EGMontageHas && window.EGMontageHas(data.url);
        cut.textContent = inRoom ? "In the cutting room" : "Add to the montage";
        cut.classList.toggle("is-on", Boolean(inRoom));
      };
      cut.addEventListener("click", () => {
        window.EGMontageAdd(data.url, prompt, isImage ? "image" : "video", meta);
        settle();
        const room = document.getElementById("montage-box");
        if (room) room.scrollIntoView({ block: "start", behavior: "smooth" });
      });
      settle();
      card.appendChild(cut);
    }
    if (window.EGFileButton) window.EGFileButton(card, data.url, prompt, isImage ? "image" : "video");
    if (window.EGArrived) window.EGArrived(card.dataset.origin === "oracle" ? "oracle-video" : "video", card);
  };

  const failed = (card, msg, prompt) => {
    card.classList.remove("is-working");
    card.classList.add("is-error");
    card.innerHTML = "<p>" + esc(msg) + "</p><figcaption>" + esc(prompt) + "</figcaption>";
  };

  /* Poll every 6 seconds, for up to forty minutes, moving the bar with
     whatever the server knows: the sampler's own step count where the
     machine reports it, the clock where it does not. */
  const watch = (card, id, prompt, first) => {
    let tries = 0;
    const bar = card.__bar || window.EGBar(card, {
      note: "Waiting for a machine\u2026",
      expect: (first && first.kind === "image") ? 90 : 300
    });
    card.__bar = bar;
    if (first && first.hardware) bar.gpu(first.hardware);
    if (first && first.note) bar.note(first.note);

    const tick = async () => {
      tries += 1;
      if (tries > 400) {
        bar.stop();
        return failed(card, "This has run for over forty minutes \u2014 it may still arrive; reload later.", prompt);
      }
      try {
        /* The key, if the member brought one, has to come with every check
           as well as with the submission: the order never keeps it, so it
           has nothing to poll the provider with unless the page says. */
        const own = window.EGOwnFilmKey ? window.EGOwnFilmKey() : null;
        const res = own
          ? await fetch("/api/video", {
              method: "POST",
              headers: window.EGAuthHeaders ? window.EGAuthHeaders() : { "content-type": "application/json" },
              body: JSON.stringify({ id, byok: own })
            })
          : await fetch("/api/video?id=" + encodeURIComponent(id));
        const data = await res.json().catch(() => ({}));
        if (typeof data.progress === "number") bar.set(data.progress, data.measured, data.stage || null);
        if (data.hardware) bar.gpu(data.hardware);
        if (data.status === "ready" && data.url) { bar.done(); bar.stop(); return ready(card, data, prompt); }
        if (data.status === "failed") { bar.stop(); return failed(card, data.error || "The generator gave up on that one.", prompt); }
      } catch { /* keep waiting */ }
      setTimeout(tick, 6000);
    };
    setTimeout(tick, 5000);
  };

  let busy = false;

  /* ---- continuation ----------------------------------------------------
     Set by the montage when a shot is chosen to grow the next one out of.
     It holds the parent's id and, where the browser could read the frame off
     the canvas, the frame itself — already uploaded, so the model can be
     handed a literal first frame rather than a description of one. */
  let cont = null;
  const contBox = document.getElementById("v-continues");

  const paintCont = () => {
    if (!contBox) return;
    if (!cont) { contBox.hidden = true; contBox.innerHTML = ""; return; }
    contBox.hidden = false;
    if (cont.kind === "model") {
      contBox.innerHTML =
        '<img src="' + esc(cont.thumb) + '" alt="The arrangement from the Turning Shop">' +
        '<div><p class="cont-head">Filming the Turning Shop</p>' +
        '<p class="muted xsmall">This view goes to the model as the clip\u2019s first frame, so the ' +
        'camera starts on the arrangement you built rather than on a guess at it. Write what moves, ' +
        'how the camera moves, and what it is all made of.</p>' +
        '<button type="button" class="btn btn--ghost btn--small" id="v-cont-drop">Film without it</button></div>';
      const off = document.getElementById("v-cont-drop");
      if (off) off.addEventListener("click", () => { cont = null; paintCont(); });
      return;
    }
    contBox.innerHTML =
      (cont.thumb ? '<img src="' + esc(cont.thumb) + '" alt="The frame this shot continues from">' : "") +
      '<div><p class="cont-head">Continuing from shot ' + esc(String(cont.index || "?")) + "</p>" +
      '<p class="muted xsmall">' +
      (cont.frame
        ? "The last frame goes to the model as this shot\u2019s first frame. "
        : "The frame itself could not be read off this clip, so the words and the seed carry it. ") +
      "Characters, setting, camera, light and film stock are carried over word for word \u2014 " +
      "write only what happens next.</p>" +
      (cont.carried ? '<p class="muted xsmall cont-sheet">' + esc(cont.carried) + "</p>" : "") +
      '<button type="button" class="btn btn--ghost btn--small" id="v-cont-drop">Start fresh instead</button></div>';
    const drop = document.getElementById("v-cont-drop");
    if (drop) drop.addEventListener("click", () => { cont = null; paintCont(); });
  };

  /* Called by the Turning Shop: the bench becomes the opening frame. */
  window.EGModelToFilm = (url) => {
    cont = { id: null, frame: url, thumb: url, kind: "model" };
    paintCont();
    const anchor = document.getElementById("film-box");
    if (anchor) anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    if (box) {
      box.focus();
      if (!box.value.trim()) box.placeholder = "What moves, and how the camera moves \u2014 the arrangement is already set.";
    }
  };

  /* Called by the montage. */
  window.EGExtendFrom = (info) => {
    cont = info || null;
    paintCont();
    const anchor = document.getElementById("film-box");
    if (anchor) anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    if (box) { box.focus(); if (!box.value.trim()) box.placeholder = "What happens next in this shot?"; }
  };

  const film = async (prompt) => {
    const p = String(prompt || "").trim();
    if (busy || p.length < 3) return;
    busy = true;
    btn.disabled = true;
    const label = btn.textContent;
    btn.textContent = "Generating\u2026";
    if (clear) clear.hidden = false;

    const card = document.createElement("figure");
    card.className = "draw-card is-working";
    card.innerHTML = "<figcaption>" + esc(p) + "</figcaption>";
    card.__bar = window.EGBar(card, {
      note: "Filming \u2014 about three minutes for five seconds of 480p. Leave the page open.",
      expect: 300
    });
    out.prepend(card);

    try {
      const res = await fetch("/api/video", {
        method: "POST",
        headers: window.EGAuthHeaders ? window.EGAuthHeaders() : { "content-type": "application/json" },
        body: JSON.stringify({
          prompt: p,
          aspect: (aspectEl && aspectEl.value) || "16:9",
          model: (modelEl && modelEl.value) || "hunyuan15",
          frames: Number(lengthEl && lengthEl.value) || undefined,
          name: (nameEl && nameEl.value || "").trim(),
          from: cont && cont.id ? cont.id : undefined,
          frame: cont ? cont.frame : undefined,
          sheet: cont ? cont.sheet : undefined,
          seed: cont ? cont.seed : undefined,
          byok: window.EGOwnFilmKey ? window.EGOwnFilmKey() : null
        })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.id) { card.__bar.stop(); failed(card, data.error || "The camera would not start.", p); }
      else {
        watch(card, data.id, p, data);
        cont = null;
        paintCont();
      }
    } catch {
      if (card.__bar) card.__bar.stop();
      failed(card, "No clip could be requested \u2014 this page may be running without its backend.", p);
    } finally {
      busy = false;
      btn.disabled = false;
      btn.textContent = label;
    }
  };

  form.addEventListener("submit", (e) => { e.preventDefault(); film(box.value); });
  if (examples) examples.addEventListener("click", (e) => {
    const b = e.target.closest(".chip");
    if (!b) return;
    box.value = b.textContent.trim();
    box.focus();
  });
  if (clear) clear.addEventListener("click", () => {
    out.innerHTML = "";
    clear.hidden = true;
    box.value = "";
    box.focus();
  });

  /* What each model is, in the server's words rather than the page's. */
  if (modelEl) {
    fetch("/api/video?models=1")
      .then((r) => r.json())
      .then((d) => {
        if (!d || !d.models) return;
        const notes = {};
        modelEl.innerHTML = "";
        d.models.forEach((m) => {
          notes[m.key] = m.note + (m.own_gpu ? "" : " Needs a paid route \u2014 too large for the order\u2019s own GPU.");
          const o = document.createElement("option");
          o.value = m.key;
          o.textContent = m.label;
          modelEl.appendChild(o);
        });
        const paint = () => { if (modelNote) modelNote.textContent = notes[modelEl.value] || ""; };
        modelEl.addEventListener("change", paint);
        paint();
      })
      .catch(() => {});
  }

  /* A picture queued on the order's own GPU is watched exactly like a clip. */
  window.EGJobWatch = (card, id, prompt, first) => watch(card, id, prompt, first);

  /* Clips the oracle starts for itself inside the conversation. */
  window.EGFilmWatch = (id, prompt) => {
    const card = document.createElement("figure");
    card.className = "draw-card is-working";
    card.innerHTML = "<figcaption>" + esc(prompt || "") + "</figcaption>";
    card.__bar = window.EGBar(card, { note: "The oracle is filming \u2014 about three minutes.", expect: 300 });
    card.dataset.origin = "oracle";
    out.prepend(card);
    document.getElementById("film-box").scrollIntoView({ block: "nearest", behavior: "smooth" });
    watch(card, id, prompt || "");
  };
})();

/* ------------------------------------------------------------------ *
 * The Threshold — accounts, emailed codes, and passkey biometrics.
 * ------------------------------------------------------------------ */
(function () {
  var box = document.getElementById('auth-box');
  var KEY = 'eg-session';

  /* token lives in localStorage and travels as a bearer header */
  function token() {
    try { return localStorage.getItem(KEY) || held || ''; } catch (e) { return held || ''; }
  }
  var held = '';
  function setToken(t) {
    held = t || '';
    window.__egTok = held;
    /* If storage was declined, the session lives only as long as this tab. */
    var ok = !window.EGConsent || window.EGConsent.allowed();
    try {
      if (t && ok) localStorage.setItem(KEY, t); else localStorage.removeItem(KEY);
    } catch (e) {}
  }
  window.EGToken = token;

  function post(url, body) {
    var h = { 'Content-Type': 'application/json' };
    var t = token();
    if (t) h.Authorization = 'Bearer ' + t;
    return fetch(url, { method: 'POST', headers: h, body: JSON.stringify(body || {}) })
      .then(function (r) { return r.json().then(function (d) { d._ok = r.ok; return d; }); });
  }

  /* base64url <-> bytes, the currency WebAuthn deals in */
  function fromB64(s) {
    s = String(s).replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    var bin = atob(s), out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function toB64(buf) {
    var b = new Uint8Array(buf), s = '';
    for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  if (!box) return;

  var panes = {};
  Array.prototype.forEach.call(box.querySelectorAll('.auth-pane'), function (p) {
    panes[p.getAttribute('data-pane')] = p;
  });
  function show(name) {
    Object.keys(panes).forEach(function (k) { panes[k].hidden = (k !== name); });
    box.setAttribute('data-state', name);
  }
  function say(el, text, bad) {
    if (!el) return;
    el.textContent = text || '';
    el.className = 'auth-msg' + (text ? (bad ? ' is-bad' : ' is-good') : '');
  }

  var emailIn = document.getElementById('a-email');
  var nameIn = document.getElementById('a-name');
  var msg = document.getElementById('a-msg');
  var codeMsg = document.getElementById('a-code-msg');
  var bioMsg = document.getElementById('a-bio-msg');
  var sendBtn = document.getElementById('a-send');
  var bioBtn = document.getElementById('a-bio');

  var hasWebAuthn = !!(window.PublicKeyCredential && navigator.credentials && navigator.credentials.create);
  if (hasWebAuthn && bioBtn) bioBtn.hidden = false;
  var unsupported = document.getElementById('a-bio-unsupported');
  if (!hasWebAuthn && unsupported) unsupported.hidden = false;

  /* ---------------------------------------------------- step one: code */
  var startForm = document.getElementById('auth-start-form');
  function sendCode(quiet) {
    var addr = (emailIn.value || '').trim();
    if (!addr) { say(msg, 'An address first.', true); return; }
    if (sendBtn) { sendBtn.disabled = true; sendBtn.textContent = 'Sending…'; }
    post('/api/account-start', Object.assign(
      { email: addr, name: (nameIn && nameIn.value) || '' },
      window.EGCaptcha ? window.EGCaptcha('join') : {}
    ))
      .then(function (d) {
        if (sendBtn) { sendBtn.disabled = false; sendBtn.textContent = 'Send my code'; }
        if (!d._ok) {
          if (d.captcha && window.EGCaptchaRenew) window.EGCaptchaRenew('join');
          say(quiet ? codeMsg : msg, d.error || 'That did not work.', true);
          return;
        }
        var note = document.getElementById('a-code-note');
        if (note) {
          note.textContent = (d.returning
            ? 'Welcome back. A sign-in code is on its way to ' + addr + '. '
            : 'A code is on its way to ' + addr + '. ') +
            'It lasts fifteen minutes and works once.';
        }
        if (window.EGCaptchaRenew) window.EGCaptchaRenew('join');
        say(codeMsg, quiet ? 'Another code sent.' : '', false);
        show('code');
        var ci = document.getElementById('a-code');
        if (ci) { ci.value = ''; ci.focus(); }
      })
      .catch(function () {
        if (sendBtn) { sendBtn.disabled = false; sendBtn.textContent = 'Send my code'; }
        say(msg, 'The threshold did not answer. Try again.', true);
      });
  }
  if (startForm) startForm.addEventListener('submit', function (e) { e.preventDefault(); sendCode(false); });
  var again = document.getElementById('a-again');
  if (again) again.addEventListener('click', function () { sendCode(true); });
  var back = document.getElementById('a-back');
  if (back) back.addEventListener('click', function () { say(msg, ''); show('start'); });

  /* ---------------------------------------------------- step two: enter */
  var codeForm = document.getElementById('auth-code-form');
  if (codeForm) codeForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var code = (document.getElementById('a-code').value || '').replace(/\D/g, '');
    var btn = document.getElementById('a-check');
    if (btn) { btn.disabled = true; btn.textContent = 'Checking…'; }
    post('/api/account-verify', { email: (emailIn.value || '').trim(), code: code })
      .then(function (d) {
        if (btn) { btn.disabled = false; btn.textContent = 'Verify and enter'; }
        if (!d._ok || !d.token) { say(codeMsg, d.error || 'That code was refused.', true); return; }
        setToken(d.token);
        say(codeMsg, '');
        enter(d.member);
      })
      .catch(function () {
        if (btn) { btn.disabled = false; btn.textContent = 'Verify and enter'; }
        say(codeMsg, 'The threshold did not answer.', true);
      });
  });

  /* ------------------------------------------------------- signed in UI */
  function enter(member) {
    var g = document.getElementById('a-greeting');
    var who = document.getElementById('a-who');
    var first = (member && member.name ? String(member.name).split(/\s+/)[0] : '');
    if (g) g.textContent = first ? 'Welcome, ' + first + '.' : 'Welcome.';
    if (who) {
      who.textContent = 'Signed in as ' + (member && member.email ? member.email : 'a verified member') +
        '. This session lasts thirty days unless you end it.';
    }
    show('in');
    loadKeys();
  }

  function loadKeys() {
    var list = document.getElementById('a-keys');
    if (!list) return;
    post('/api/account-me', {}).then(function (d) {
      if (!d.signed_in) { setToken(''); show('start'); return; }
      list.innerHTML = '';
      if (!d.passkeys || !d.passkeys.length) {
        var li = document.createElement('li');
        li.className = 'muted small';
        li.textContent = 'No device enrolled yet.';
        list.appendChild(li);
        return;
      }
      d.passkeys.forEach(function (k) {
        var li = document.createElement('li');
        var span = document.createElement('span');
        span.textContent = k.label || 'A device';
        var drop = document.createElement('button');
        drop.type = 'button';
        drop.className = 'linkish';
        drop.textContent = 'forget';
        drop.addEventListener('click', function () {
          post('/api/account-passkey', { action: 'forget', id: k.id }).then(loadKeys);
        });
        li.appendChild(span);
        li.appendChild(drop);
        list.appendChild(li);
      });
    });
  }

  var out = document.getElementById('a-signout');
  if (out) out.addEventListener('click', function () {
    post('/api/account-signout', {}).catch(function () {}).then(function () {
      setToken('');
      say(msg, 'Signed out. The door is only ever closed, never locked.');
      show('start');
    });
  });

  /* --------------------------------------------- enrol a biometric key */
  function deviceLabel() {
    var u = navigator.userAgent || '';
    if (/iPhone|iPad/.test(u)) return 'iPhone or iPad (Face ID / Touch ID)';
    if (/Macintosh/.test(u)) return 'Mac (Touch ID)';
    if (/Android/.test(u)) return 'Android device (fingerprint)';
    if (/Windows/.test(u)) return 'Windows (Hello)';
    return 'This device';
  }

  var addKey = document.getElementById('a-add-key');
  if (addKey) addKey.addEventListener('click', function () {
    if (!hasWebAuthn) { say(bioMsg, 'This browser has no passkey support.', true); return; }
    addKey.disabled = true;
    say(bioMsg, 'Ask your device…');
    post('/api/account-passkey', { action: 'register-options' })
      .then(function (o) {
        if (!o._ok) throw new Error(o.error || 'The server refused.');
        return navigator.credentials.create({
          publicKey: {
            challenge: fromB64(o.challenge),
            rp: o.rp,
            user: {
              id: fromB64(o.user.id),
              name: o.user.name,
              displayName: o.user.displayName
            },
            pubKeyCredParams: o.pubKeyCredParams,
            authenticatorSelection: o.authenticatorSelection,
            timeout: o.timeout,
            attestation: o.attestation,
            excludeCredentials: (o.excludeCredentials || []).map(function (c) {
              return { type: 'public-key', id: fromB64(c.id) };
            })
          }
        }).then(function (cred) {
          /* getPublicKey() hands us SPKI directly — no CBOR to unpick */
          var spki = cred.response.getPublicKey && cred.response.getPublicKey();
          if (!spki) throw new Error('This device did not offer a readable public key.');
          return post('/api/account-passkey', {
            action: 'register',
            credId: toB64(cred.rawId),
            publicKey: toB64(spki),
            challenge: o.challenge,
            clientDataJSON: toB64(cred.response.clientDataJSON),
            label: deviceLabel()
          });
        });
      })
      .then(function (d) {
        addKey.disabled = false;
        if (!d._ok) { say(bioMsg, d.error || 'The key was not accepted.', true); return; }
        say(bioMsg, d.message || 'Enrolled.');
        loadKeys();
      })
      .catch(function (err) {
        addKey.disabled = false;
        var m = (err && err.name === 'NotAllowedError')
          ? 'The device declined, or the prompt was dismissed.'
          : (err && err.message) || 'The enrolment failed.';
        say(bioMsg, m, true);
      });
  });

  /* ------------------------------------------- sign in with the finger */
  if (bioBtn) bioBtn.addEventListener('click', function () {
    var addr = (emailIn.value || '').trim();
    if (!addr) { say(msg, 'Type your address first, then press this.', true); return; }
    bioBtn.disabled = true;
    say(msg, 'Ask your device…');
    post('/api/account-passkey', { action: 'login-options', email: addr })
      .then(function (o) {
        if (!o._ok) throw new Error(o.error || 'No passkey here.');
        return navigator.credentials.get({
          publicKey: {
            challenge: fromB64(o.challenge),
            rpId: o.rpId,
            timeout: o.timeout,
            userVerification: o.userVerification,
            allowCredentials: (o.allowCredentials || []).map(function (c) {
              return { type: 'public-key', id: fromB64(c.id) };
            })
          }
        }).then(function (as) {
          return post('/api/account-passkey', {
            action: 'login',
            credId: toB64(as.rawId),
            challenge: o.challenge,
            authenticatorData: toB64(as.response.authenticatorData),
            clientDataJSON: toB64(as.response.clientDataJSON),
            signature: toB64(as.response.signature)
          });
        });
      })
      .then(function (d) {
        bioBtn.disabled = false;
        if (!d._ok || !d.token) { say(msg, d.error || 'That was refused.', true); return; }
        setToken(d.token);
        say(msg, '');
        enter(d.member);
      })
      .catch(function (err) {
        bioBtn.disabled = false;
        var m = (err && err.name === 'NotAllowedError')
          ? 'The device declined, or the prompt was dismissed.'
          : (err && err.message) || 'The sign-in failed.';
        say(msg, m, true);
      });
  });

  /* already carrying a session? walk straight in */
  if (token()) {
    post('/api/account-me', {}).then(function (d) {
      if (d && d.signed_in) enter(d.member); else setToken('');
    }).catch(function () {});
  }
})();

/* ------------------------------------------------------------------ *
 * Consent. Nothing is written to the visitor's machine until they say
 * yes. Declining is a real answer: the stores are emptied and the
 * writing helpers refuse from then on.
 * ------------------------------------------------------------------ */
(function () {
  var KEY = 'eg-consent';
  var MINE = ['eg-session', 'eg-thread', 'eg-name', 'eg-draft'];

  function readChoice() {
    try { return localStorage.getItem(KEY) || ''; } catch (e) { return 'declined'; }
  }
  function wipe() {
    try {
      MINE.forEach(function (k) { localStorage.removeItem(k); sessionStorage.removeItem(k); });
    } catch (e) {}
  }

  var consent = {
    choice: function () { return readChoice(); },
    allowed: function () { return readChoice() === 'accepted'; },
    set: function (value) {
      try { localStorage.setItem(KEY, value); } catch (e) {}
      if (value !== 'accepted') wipe();
      document.documentElement.setAttribute('data-consent', value);
    }
  };
  window.EGConsent = consent;
  document.documentElement.setAttribute('data-consent', readChoice() || 'unasked');

  var gate = document.getElementById('cookie-gate');

  function open() {
    if (!gate) return;
    gate.hidden = false;
    requestAnimationFrame(function () { gate.classList.add('is-up'); });
  }
  function close() {
    if (!gate) return;
    gate.classList.remove('is-up');
    setTimeout(function () { gate.hidden = true; }, 420);
  }

  if (gate && !readChoice()) setTimeout(open, 900);

  var yes = document.getElementById('cookie-yes');
  var no = document.getElementById('cookie-no');
  if (yes) yes.addEventListener('click', function () { consent.set('accepted'); close(); });
  if (no) no.addEventListener('click', function () { consent.set('declined'); close(); });

  var reopen = document.getElementById('cookie-reopen');
  if (reopen) reopen.addEventListener('click', function () {
    open();
    if (gate) gate.scrollIntoView({ block: 'nearest' });
  });
})();

/* ------------------------------------------------------------------ *
 * Arrivals. An image or a clip can take minutes, by which time the
 * asker has usually looked away. Say so when one lands: a note in the
 * corner, the tab title flashing, and a soft pair of notes.
 * ------------------------------------------------------------------ */
(function () {
  var realTitle = document.title;
  var flashing = null;
  var tray = null;

  function titleFlash(text) {
    if (!document.hidden) return;
    var on = false;
    clearInterval(flashing);
    flashing = setInterval(function () {
      on = !on;
      document.title = on ? text : realTitle;
    }, 1100);
  }
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) { clearInterval(flashing); document.title = realTitle; }
  });

  /* Two soft notes, synthesised — no file to fetch, no autoplay of media. */
  function chime() {
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      var ctx = new Ctx();
      if (ctx.state === 'suspended' && ctx.resume) ctx.resume();
      [[528, 0], [792, 0.17]].forEach(function (pair) {
        var osc = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = pair[0];
        var t = ctx.currentTime + pair[1];
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.exponentialRampToValueAtTime(0.09, t + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
        osc.connect(gain).connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 1);
      });
      setTimeout(function () { if (ctx.close) ctx.close(); }, 2200);
    } catch (e) { /* silence is an acceptable failure */ }
  }

  function note(text, node) {
    if (!tray) {
      tray = document.createElement('div');
      tray.className = 'arrival-tray';
      tray.setAttribute('aria-live', 'polite');
      document.body.appendChild(tray);
    }
    var el = document.createElement('button');
    el.type = 'button';
    el.className = 'arrival';
    el.innerHTML = '<span class="arrival-mark" aria-hidden="true">✦</span><span>' +
      String(text).replace(/[&<>]/g, '') + '</span>';
    el.addEventListener('click', function () {
      if (node && node.scrollIntoView) node.scrollIntoView({ block: 'center', behavior: 'smooth' });
      el.remove();
    });
    tray.appendChild(el);
    requestAnimationFrame(function () { el.classList.add('is-up'); });
    setTimeout(function () {
      el.classList.remove('is-up');
      setTimeout(function () { el.remove(); }, 500);
    }, 9000);
  }

  /* kind: 'image' | 'video' | 'oracle-image'; node: the card that arrived */
  window.EGArrived = function (kind, node, how) {
    var words = {
      image: 'Your image is ready.',
      video: 'Your clip has finished filming.',
      'oracle-image': 'The oracle drew something for you.',
      'oracle-video': 'The oracle\u2019s clip has arrived.'
    };
    var text = words[kind] || 'Something new has arrived.';
    if (how) text += ' ' + how;

    if (node) {
      node.classList.add('just-arrived');
      setTimeout(function () { node.classList.remove('just-arrived'); }, 4000);
      if (!document.hidden) {
        var box = node.getBoundingClientRect();
        var seen = box.top < window.innerHeight && box.bottom > 0;
        if (!seen) node.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
    }
    note(text, node);
    titleFlash('\u2726 ' + text);
    chime();
  };
})();

/* ------------------------------------------------------------------ *
 * The letter to Ed. Posts to /api/letter, which stores it, forwards it
 * and sends the asker an acknowledgement by return of post.
 * ------------------------------------------------------------------ */
(function () {
  var form = document.getElementById('letter-form');
  if (!form) return;
  var btn = document.getElementById('letter-send');
  var msg = document.getElementById('letter-msg');

  function say(text, bad) {
    if (!msg) return;
    msg.textContent = text || '';
    msg.className = 'auth-msg' + (text ? (bad ? ' is-bad' : ' is-good') : '');
  }
  function field(id) {
    var el = document.getElementById(id);
    return el ? el.value : '';
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (btn) { btn.disabled = true; btn.textContent = 'Sending\u2026'; }
    say('');
    fetch('/api/letter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({
        name: field('name'),
        email: field('email'),
        topic: field('topic'),
        question: field('question'),
        public: field('public'),
        website: field('website')
      }, window.EGCaptcha ? window.EGCaptcha('letter') : {}))
    })
      .then(function (r) { return r.json().then(function (d) { d._ok = r.ok; return d; }); })
      .then(function (d) {
        if (btn) { btn.disabled = false; btn.textContent = 'Send the Question'; }
        if (window.EGCaptchaRenew) window.EGCaptchaRenew('letter');
        if (!d._ok) { say(d.error || 'The letter was refused.', true); return; }
        say(d.message || 'Your letter is in the pile.');
        var q = document.getElementById('question');
        if (q) q.value = '';
      })
      .catch(function () {
        if (btn) { btn.disabled = false; btn.textContent = 'Send the Question'; }
        say('The post did not go through \u2014 email shakradragon@gmail.com instead.', true);
      });
  });
})();

/* ------------------------------------------------------------------ *
 * One place that knows how to speak to a protected endpoint.
 * ------------------------------------------------------------------ */
(function () {
  window.EGAuthToken = function () {
    try { return localStorage.getItem('eg-session') || window.__egTok || ''; }
    catch (e) { return window.__egTok || ''; }
  };
  window.EGAuthHeaders = function () {
    var h = { 'content-type': 'application/json' };
    var t = window.EGAuthToken();
    if (t) h.Authorization = 'Bearer ' + t;
    return h;
  };
  /* Members-only state, fetched once per page and shared. */
  var cached = null;
  window.EGStudio = function () {
    if (cached) return cached;
    cached = fetch('/api/account-me', { method: 'POST', headers: window.EGAuthHeaders(), body: '{}' })
      .then(function (r) { return r.json(); })
      .catch(function () { return { signed_in: false, studio: false }; });
    return cached;
  };
})();

/* ------------------------------------------------------------------ *
 * The studio door, as the visitor meets it. The image and video panels
 * stay shuttered until the account is signed in, the address confirmed
 * and the age and identity check passed. The server enforces the same
 * thing; this is only so nobody wastes a prompt finding out.
 * ------------------------------------------------------------------ */
(function () {
  var panels = [
    { el: document.getElementById('draw-box'), noun: 'Image generation' },
    { el: document.getElementById('film-box'), noun: 'Video generation' }
  ].filter(function (p) { return p.el; });
  if (!panels.length) return;

  var WORDS = {
    signin: {
      head: 'Members only',
      body: 'The generators are open to signed-in members who are over eighteen and have passed the ' +
            'identity check. Everything else here — the oracle, every page, every answer — stays open ' +
            'to everyone, and always will.',
      cta: 'Sign in or create an account'
    },
    verify: {
      head: 'Confirm your address',
      body: 'Your account exists but the address has not been confirmed yet. Enter the six-digit code we ' +
            'emailed you and the studio opens.',
      cta: 'Enter my code'
    },
    identity: {
      head: 'Age and identity check needed',
      body: 'Making images and video needs proof of age. There are two ways through: let the camera ' +
            'look at your face, which takes seconds and keeps nothing, or show a government-issued ' +
            'document, which always works. Asked once, and never shown on the site.',
      cta: 'Pass the check'
    }
  };

  function shutter(panel, state) {
    var w = WORDS[state] || WORDS.signin;
    var form = panel.el.querySelector('form');
    var out = panel.el.querySelector('.draw-out');
    if (form) form.hidden = true;
    if (out) out.hidden = true;
    panel.el.classList.add('is-shut');

    var gate = document.createElement('div');
    gate.className = 'studio-gate';
    gate.innerHTML =
      '<p class="gate-mark" aria-hidden="true">&#9737;</p>' +
      '<h4>' + w.head + '</h4>' +
      '<p class="muted small">' + w.body + '</p>' +
      '<p><button type="button" class="btn gate-go">' + w.cta + '</button></p>' +
      '<p class="muted xsmall">' + panel.noun + ' is gated because a generator can be made to produce ' +
      'things a person should be accountable for. The check puts a name behind every prompt. ' +
      'Nothing is checked, and no account is needed, to talk to the oracle.</p>';
    var anchor = form || out || panel.el.lastElementChild;
    panel.el.insertBefore(gate, anchor);
    var go = gate.querySelector('.gate-go');
    if (go) go.addEventListener('click', function () {
      if (window.EGNeedCheck) window.EGNeedCheck(state);
      else location.href = '/join/';
    });
  }

  function open(panel) {
    panel.el.classList.remove('is-shut');
    var g = panel.el.querySelector('.studio-gate');
    if (g) g.remove();
    var form = panel.el.querySelector('form');
    var out = panel.el.querySelector('.draw-out');
    if (form) form.hidden = false;
    if (out) out.hidden = false;
  }

  /* Shut by default, so a slow reply never leaves the door ajar. */
  panels.forEach(function (p) { shutter(p, 'signin'); });

  window.EGStudio().then(function (me) {
    var state = !me || !me.signed_in ? 'signin'
      : (!me.member || !me.member.verified) ? 'verify'
      : me.studio ? 'open' : 'identity';
    panels.forEach(function (p) {
      if (state === 'open') { open(p); return; }
      var g = p.el.querySelector('.studio-gate');
      if (g) g.remove();
      shutter(p, state);
    });
  });
})();

/* ------------------------------------------------------------------ *
 * The age and identity check on the Join page.
 * ------------------------------------------------------------------ */
(function () {
  var form = document.getElementById('id-form');
  if (!form) return;
  /* Opened inside the sheet: show the door and nothing else, and tell the
     page that opened us the moment it is passed. */
  var only = /[?&]only=check\b/.test(location.search);
  if (only) document.body.classList.add('only-check');
  var msg = document.getElementById('i-msg');
  var state = document.getElementById('a-id-state');
  var btn = document.getElementById('i-send');
  var fileIn = document.getElementById('i-doc');
  var preview = document.getElementById('i-preview');
  var carried = null;

  function say(text, bad) {
    if (!msg) return;
    msg.textContent = text || '';
    msg.className = 'auth-msg' + (text ? (bad ? ' is-bad' : ' is-good') : '');
  }

  function passed(member) {
    form.hidden = true;
    if (only && parent !== window) {
      try { parent.postMessage('eg-check-passed', location.origin); } catch (e) { /* no parent */ }
    }
    if (state) {
      state.innerHTML = '<strong class="gate-open">The studio is open to you.</strong> ' +
        'Checked' + (member && member.legal_name ? ' as ' + member.legal_name : '') +
        '. Image and video generation are unlocked on the <a href="/ask-ed/">Ask Ed</a> page.';
    }
  }

  /* Read the document once, as a data URL, so the post is a single JSON body. */
  if (fileIn) fileIn.addEventListener('change', function () {
    var f = fileIn.files && fileIn.files[0];
    carried = null;
    if (!f) { if (preview) preview.textContent = ''; return; }
    if (f.size > 6 * 1024 * 1024) {
      say('That image is over 6 MB. A normal phone photo is plenty.', true);
      fileIn.value = '';
      return;
    }
    var r = new FileReader();
    r.onload = function () {
      carried = r.result;
      if (preview) {
        preview.textContent = f.name + ' \u00b7 ' + Math.round(f.size / 1024) + ' KB \u00b7 held in this ' +
          'page only until you submit.';
      }
      say('');
    };
    r.onerror = function () { say('That file could not be read.', true); };
    r.readAsDataURL(f);
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!carried) { say('Attach a photograph of the document.', true); return; }
    var dec = document.getElementById('i-declare');
    if (!dec || !dec.checked) { say('The declaration has to be ticked.', true); return; }

    if (btn) { btn.disabled = true; btn.textContent = 'Checking\u2026'; }
    say('');
    fetch('/api/account-identity', {
      method: 'POST',
      headers: window.EGAuthHeaders(),
      body: JSON.stringify({
        action: 'submit',
        legal_name: document.getElementById('i-legal').value,
        dob: document.getElementById('i-dob').value,
        country: document.getElementById('i-country').value,
        doc_type: document.getElementById('i-doc-type').value,
        doc: carried,
        declaration: true
      })
    })
      .then(function (r) { return r.json().then(function (d) { d._ok = r.ok; return d; }); })
      .then(function (d) {
        if (btn) { btn.disabled = false; btn.textContent = 'Submit the check'; }
        if (!d._ok) { say(d.error || 'The check did not pass.', true); return; }
        carried = null;
        say(d.message || 'Checked.');
        passed({ legal_name: document.getElementById('i-legal').value });
      })
      .catch(function () {
        if (btn) { btn.disabled = false; btn.textContent = 'Submit the check'; }
        say('The check could not be sent. Try again.', true);
      });
  });

  /* Already checked? Do not ask again. */
  if (window.EGStudio) window.EGStudio().then(function (me) {
    if (me && me.studio) passed(me.member);
  });
})();

/* ------------------------------------------------------------------ *
 * The face scan. Phone camera or webcam, three frames, no upload until
 * the button is pressed, nothing kept afterwards.
 * ------------------------------------------------------------------ */
(function () {
  var box = document.getElementById('scan-box');
  if (!box) return;

  var video = document.getElementById('scan-video');
  var ring = document.getElementById('scan-ring');
  var hint = document.getElementById('scan-hint');
  var msg = document.getElementById('scan-msg');
  var startBtn = document.getElementById('scan-start');
  var shootBtn = document.getElementById('scan-shoot');
  var stopBtn = document.getElementById('scan-stop');
  var stream = null;

  var canCamera = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  if (!canCamera) {
    var un = document.getElementById('scan-unsupported');
    if (un) un.hidden = false;
    if (startBtn) startBtn.disabled = true;
  }

  function say(text, bad) {
    if (!msg) return;
    msg.textContent = text || '';
    msg.className = 'auth-msg' + (text ? (bad ? ' is-bad' : ' is-good') : '');
  }

  function stop() {
    if (stream) {
      stream.getTracks().forEach(function (t) { t.stop(); });
      stream = null;
    }
    if (video) { video.srcObject = null; video.hidden = true; }
    if (ring) ring.hidden = true;
    if (shootBtn) shootBtn.hidden = true;
    if (stopBtn) stopBtn.hidden = true;
    if (startBtn) { startBtn.hidden = false; startBtn.disabled = !canCamera; }
  }

  if (startBtn) startBtn.addEventListener('click', function () {
    say('Asking for the camera\u2026');
    navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'user', width: { ideal: 960 }, height: { ideal: 960 } },
      audio: false
    }).then(function (s) {
      stream = s;
      video.srcObject = s;
      video.hidden = false;
      if (ring) ring.hidden = false;
      startBtn.hidden = true;
      shootBtn.hidden = false;
      stopBtn.hidden = false;
      say('');
      if (hint) hint.textContent = 'Look straight at the lens, keep still, and press the button.';
      return video.play().catch(function () {});
    }).catch(function (err) {
      var m = (err && err.name === 'NotAllowedError')
        ? 'The camera was refused. Allow it in the address bar, or use the document check below.'
        : 'No camera could be opened. The document check below always works.';
      say(m, true);
    });
  });

  if (stopBtn) stopBtn.addEventListener('click', function () { stop(); say('Camera off.'); });

  /* One frame, square, downscaled to something a vision model will read. */
  function frame() {
    var w = video.videoWidth, h = video.videoHeight;
    if (!w || !h) return null;
    var side = Math.min(w, h);
    var size = 640;
    var c = document.createElement('canvas');
    c.width = size; c.height = size;
    var ctx = c.getContext('2d');
    ctx.drawImage(video, (w - side) / 2, (h - side) / 2, side, side, 0, 0, size, size);
    return c.toDataURL('image/jpeg', 0.86);
  }

  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  /* ---------------------------------------------------------------- *
   * The reader. A published face model, fetched from a CDN and run
   * entirely in this page: the camera frames never leave the browser
   * to produce the estimate. No key, no account with anyone, no call
   * to a model company. If it will not load we fall back to asking the
   * server, and failing that, to the document.
   * ---------------------------------------------------------------- */
  var FACE_LIB = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.15/dist/face-api.esm.js';
  var FACE_MODELS = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.15/model';
  var api = null;
  var loading = null;

  function loadReader() {
    if (api) return Promise.resolve(api);
    if (loading) return loading;
    loading = import(FACE_LIB)
      .then(function (mod) {
        var f = mod.default || mod;
        return Promise.all([
          f.nets.tinyFaceDetector.loadFromUri(FACE_MODELS),
          f.nets.ageGenderNet.loadFromUri(FACE_MODELS)
        ]).then(function () { api = f; return f; });
      })
      .catch(function (err) {
        loading = null;
        throw new Error('The face reader would not load: ' + ((err && err.message) || 'blocked'));
      });
    return loading;
  }

  /* Take several readings and use the median — a single frame is noisy. */
  function readAge(samples) {
    return loadReader().then(function (f) {
      var opts = new f.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.4 });
      var ages = [];
      var faces = 0;
      var chain = Promise.resolve();
      for (var i = 0; i < samples; i++) {
        chain = chain.then(function () {
          return f.detectAllFaces(video, opts).withAgeAndGender().then(function (found) {
            if (found && found.length) {
              faces = Math.max(faces, found.length);
              found.sort(function (a, b) { return b.detection.box.area - a.detection.box.area; });
              ages.push(found[0].age);
            }
            return wait(260);
          });
        });
      }
      return chain.then(function () {
        if (!ages.length) return { face: false, faces: 0, samples: samples };
        ages.sort(function (a, b) { return a - b; });
        var mid = ages[Math.floor(ages.length / 2)];
        return {
          face: true,
          faces: faces,
          age: Math.round(mid),
          low: Math.round(ages[0]),
          high: Math.round(ages[ages.length - 1]),
          samples: ages.length,
          /* tight spread across frames means a steady reading */
          confidence: Math.max(0.35, Math.min(0.95, 1 - (ages[ages.length - 1] - ages[0]) / 24)),
          model: 'face-api/age_gender'
        };
      });
    });
  }

  if (shootBtn) shootBtn.addEventListener('click', function () {
    if (!stream) return;
    shootBtn.disabled = true;
    var shots = [];

    say('Hold still \u2014 reading your face in this browser\u2026');
    if (ring) ring.classList.add('is-reading');
    var local = null;

    /* Three frames a third of a second apart: a still photograph held up to
       the lens tends to give itself away across them. */
    frame() && shots.push(frame());
    wait(350)
      .then(function () { var f = frame(); if (f) shots.push(f); return wait(350); })
      .then(function () { var f = frame(); if (f) shots.push(f); })
      .then(function () {
        if (!shots.length) throw new Error('The camera gave no picture.');
        /* The estimate happens here, in the page, before anything is sent. */
        return readAge(7).catch(function (err) {
          say((err && err.message) || 'The face reader would not load.', true);
          return null;
        });
      })
      .then(function (reading) {
        local = reading;
        if (reading && reading.face === false) {
          throw new Error('No face found in the frame. Fill the oval with your head, ' +
            'face a window, and try again.');
        }
        if (reading && reading.age) {
          say('Read as about ' + reading.age + ' \u2014 confirming\u2026');
        } else {
          say('Sending the frames to be read\u2026');
        }
        return fetch('/api/account-face', {
          method: 'POST',
          headers: window.EGAuthHeaders(),
          body: JSON.stringify({ frames: shots.slice(0, 3), client_estimate: local })
        });
      })
      .then(function (r) { return r.json().then(function (d) { d._ok = r.ok; return d; }); })
      .then(function (d) {
        shots.length = 0;                       /* drop the frames on this side too */
        shootBtn.disabled = false;
        if (ring) ring.classList.remove('is-reading');

        if (d.ok) {
          stop();
          say(d.message || 'Checked. The studio is open.');
          box.classList.add('is-passed');
          var form = document.getElementById('id-form');
          var or = document.querySelector('.scan-or');
          if (form) form.hidden = true;
          if (or) or.hidden = true;
          var state = document.getElementById('a-id-state');
          if (state) {
            state.innerHTML = '<strong class="gate-open">The studio is open to you.</strong> ' +
              'Age confirmed by face scan' + (d.estimated ? ' \u00b7 read as about ' + d.estimated : '') +
              '. Image and video generation are unlocked on the <a href="/ask-ed/">Ask Ed</a> page.';
          }
          return;
        }

        say(d.message || d.error || 'The scan did not settle it.', !d.inconclusive ? true : false);
        if (d.fallback === 'document') {
          stop();
          var f2 = document.getElementById('id-form');
          if (f2) {
            f2.scrollIntoView({ block: 'center', behavior: 'smooth' });
            f2.classList.add('is-wanted');
            setTimeout(function () { f2.classList.remove('is-wanted'); }, 3000);
          }
        }
      })
      .catch(function (err) {
        shootBtn.disabled = false;
        if (ring) ring.classList.remove('is-reading');
        say((err && err.message) || 'The reading failed. Try again, or use the document check.', true);
      });
  });

  window.addEventListener('pagehide', stop);

  /* Already checked? Put the camera away before it is ever opened. */
  if (window.EGStudio) window.EGStudio().then(function (me) {
    if (me && me.studio) { box.hidden = true; var or = document.querySelector('.scan-or'); if (or) or.hidden = true; }
  });
})();

/* ------------------------------------------------------------------ *
 * The gate-word. Self-hosted, drawn as SVG on the server, no third
 * party told who is knocking. window.EGCaptcha(name) hands back the
 * token and the typed answer; .renew(name) draws a fresh one.
 * ------------------------------------------------------------------ */
(function () {
  var boxes = {};

  function fetchWord(box) {
    var art = box.querySelector('[data-captcha-art]');
    if (art) art.innerHTML = '<span class="captcha-wait">drawing\u2026</span>';
    box.dataset.token = '';
    return fetch('/api/captcha')
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.svg) throw new Error('no word');
        box.dataset.token = d.token;
        if (art) art.innerHTML = d.svg;
      })
      .catch(function () {
        if (art) art.innerHTML = '<span class="captcha-wait">The gate-word could not be drawn. ' +
          'Press the arrow to try again.</span>';
      });
  }

  Array.prototype.forEach.call(document.querySelectorAll('[data-captcha]'), function (box) {
    boxes[box.getAttribute('data-captcha')] = box;
    fetchWord(box);
    var again = box.querySelector('[data-captcha-new]');
    if (again) again.addEventListener('click', function () {
      var input = box.querySelector('[data-captcha-input]');
      if (input) input.value = '';
      fetchWord(box);
    });
    /* Typing it in upper case is kinder to read back. */
    var input = box.querySelector('[data-captcha-input]');
    if (input) input.addEventListener('input', function () {
      var at = input.selectionStart;
      input.value = input.value.toUpperCase();
      try { input.setSelectionRange(at, at); } catch (e) {}
    });
  });

  window.EGCaptcha = function (name) {
    var box = boxes[name];
    if (!box) return {};
    var input = box.querySelector('[data-captcha-input]');
    return {
      captcha_token: box.dataset.token || '',
      captcha: (input && input.value) || ''
    };
  };
  window.EGCaptchaRenew = function (name) {
    var box = boxes[name];
    if (!box) return;
    var input = box.querySelector('[data-captcha-input]');
    if (input) input.value = '';
    fetchWord(box);
  };
})();

/* ------------------------------------------------------------------ *
 * The head's sign-in link knows whether you are already inside.
 * ------------------------------------------------------------------ */
(function () {
  var link = document.getElementById('head-join');
  if (!link || !window.EGStudio) return;
  window.EGStudio().then(function (me) {
    if (!me || !me.signed_in) return;

    /* The chip says who you are, not what your address is. An email address
       printed into the furniture of every page is a small privacy leak — it
       is on screen in every screenshot, every shared tab and every projector
       — and it is never the thing the reader needs. The address lives on the
       account page, where you went to look for it. */
    var member = me.member || {};
    var name = String(member.name || '').trim();
    var label = name ? name.split(/\s+/)[0] : '';
    if (!label) {
      /* No name on the register yet — fall back to the address's local part,
         which is a handle rather than a contactable address. */
      var local = String(member.email || '').split('@')[0].replace(/[._-]+/g, ' ').trim();
      label = local ? local.charAt(0).toUpperCase() + local.slice(1) : 'Member';
    }

    link.classList.add('is-in');
    link.href = '/account/';
    link.setAttribute('title', name ? 'Logged in as ' + name : 'Your account');
    var mark = link.querySelector('.head-join-mark');
    if (mark) mark.textContent = '\u2726';
    var text = link.querySelector('.head-join-text');
    if (text) {
      text.classList.add('head-join-addr');
      text.textContent = '';
      var lead = document.createElement('span');
      lead.className = 'head-join-lead';
      lead.textContent = 'Logged in as';
      var who = document.createElement('span');
      who.className = 'head-join-who';
      who.textContent = label;
      text.appendChild(lead);
      text.appendChild(who);
    }

    /* On a phone the signed-in chip is too wide for the brand row: it
       crowded the logotype and overlapped the order's name. So below 860px
       it is lifted out of the head and set down in a bar of its own,
       directly underneath, where it has the width to itself. It goes back
       where it belongs the moment the window is wide again. */
    var head = document.querySelector('.site-head');
    var slot = link.parentNode;
    var bar = null;
    var narrow = window.matchMedia('(max-width: 860px)');
    function place() {
      if (!head || !slot) return;
      if (narrow.matches) {
        if (!bar) {
          bar = document.createElement('div');
          bar.className = 'head-you-bar';
        }
        if (bar.parentNode !== head.parentNode) {
          head.parentNode.insertBefore(bar, head.nextSibling);
        }
        if (link.parentNode !== bar) bar.appendChild(link);
      } else {
        if (link.parentNode !== slot) slot.insertBefore(link, slot.querySelector('.nav-toggle'));
        if (bar && bar.parentNode) bar.parentNode.removeChild(bar);
      }
    }
    place();
    if (narrow.addEventListener) narrow.addEventListener('change', place);
    else if (narrow.addListener) narrow.addListener(place);
  }).catch(function () {});
})();

/* ------------------------------------------------------------------ *
 * The register — your own page.
 * ------------------------------------------------------------------ */
(function () {
  var wait = document.getElementById('acct-wait');
  if (!wait) return;
  var out = document.getElementById('acct-out');
  var none = document.getElementById('acct-none');

  function when(value) {
    if (!value) return '—';
    var d = new Date(value);
    if (isNaN(d.getTime())) return '—';
    return d.toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' });
  }
  function row(dl, term, detail) {
    var dt = document.createElement('dt');
    dt.textContent = term;
    var dd = document.createElement('dd');
    if (detail && detail.nodeType) dd.appendChild(detail); else dd.textContent = detail;
    dl.appendChild(dt);
    dl.appendChild(dd);
  }

  window.EGStudio().then(function (me) {
    wait.hidden = true;
    if (!me || !me.signed_in) { if (none) none.hidden = false; return; }
    if (out) out.hidden = false;

    var m = me.member || {};
    var nameEl = document.getElementById('acct-name');
    var mailEl = document.getElementById('acct-email');
    if (nameEl) nameEl.textContent = m.name || m.legal_name || 'Member of the order';
    if (mailEl) mailEl.textContent = m.email || '';

    var dl = document.getElementById('acct-grid');
    if (dl) {
      dl.innerHTML = '';
      row(dl, 'Joined', when(m.joined));
      row(dl, 'Address', m.verified ? 'Confirmed' : 'Not confirmed yet');
      row(dl, 'Signed in by', me.method === 'passkey' ? 'Passkey — face, finger or PIN' : 'Emailed code');
      row(dl, 'This session ends', when(me.session && me.session.expires));
      row(dl, 'Devices signed in', String((me.counts && me.counts.sessions) || 1));
      row(dl, 'Letters to Ed', String((me.counts && me.counts.letters) || 0));
      if (m.legal_name) row(dl, 'Checked as', m.legal_name);
    }

    var studio = document.getElementById('acct-studio');
    if (studio) {
      if (me.studio) {
        var how = m.id_doc_type === 'face-scan' ? 'a face scan' : 'a document';
        studio.innerHTML = '<strong class="gate-open">Open to you.</strong> Age confirmed by ' + how +
          (m.checked ? ' on ' + when(m.checked) : '') +
          '. Image and video generation are unlocked on the <a href="/ask-ed/">Ask Ed</a> page.';
      } else if (!m.verified) {
        studio.innerHTML = 'Shut. Confirm your address first — <a href="/join/">enter the code</a>.';
      } else {
        studio.innerHTML = 'Shut. The generators need an age check: a look at your face, or a document. ' +
          '<a href="/join/">Pass the check</a> and it opens at once. Everything else here is already yours.';
      }
    }

    /* the mailing list */
    var listNote = document.getElementById('acct-list');
    var listBtn = document.getElementById('acct-list-btn');
    var listMsg = document.getElementById('acct-list-msg');

    function paintList(on) {
      if (listNote) {
        listNote.innerHTML = on
          ? '<strong class="gate-open">You are on the list.</strong> New pages, the podcast, and the ' +
            'occasional long letter. Every one of them carries the way out at its foot.'
          : 'You are <strong>off the list</strong>. You will still get post you actually asked for — a ' +
            'sign-in code, or a reply to a letter you sent Ed.';
      }
      if (listBtn) listBtn.textContent = on ? 'Leave the list' : 'Rejoin the list';
    }
    var on = m.subscribed !== false;
    paintList(on);

    if (listBtn) listBtn.addEventListener('click', function () {
      listBtn.disabled = true;
      fetch('/api/unsubscribe', {
        method: 'POST',
        headers: window.EGAuthHeaders(),
        body: JSON.stringify({ on: !on })
      })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          listBtn.disabled = false;
          if (d && d.ok) {
            on = Boolean(d.subscribed);
            paintList(on);
            if (listMsg) { listMsg.textContent = d.message || ''; listMsg.className = 'auth-msg is-good'; }
          } else if (listMsg) {
            listMsg.textContent = (d && d.error) || 'That did not take.';
            listMsg.className = 'auth-msg is-bad';
          }
        })
        .catch(function () {
          listBtn.disabled = false;
          if (listMsg) { listMsg.textContent = 'That did not take.'; listMsg.className = 'auth-msg is-bad'; }
        });
    });

    var keys = document.getElementById('acct-keys');
    if (keys) {
      keys.innerHTML = '';
      if (!me.passkeys || !me.passkeys.length) {
        var li = document.createElement('li');
        li.className = 'muted small';
        li.textContent = 'No passkey enrolled — you sign in with an emailed code.';
        keys.appendChild(li);
      } else {
        me.passkeys.forEach(function (k) {
          var li2 = document.createElement('li');
          var a = document.createElement('span');
          a.textContent = k.label || 'A device';
          var b = document.createElement('span');
          b.className = 'muted xsmall';
          b.textContent = k.last_used ? 'last used ' + when(k.last_used) : 'added ' + when(k.created_at);
          li2.appendChild(a);
          li2.appendChild(b);
          keys.appendChild(li2);
        });
      }
    }
  }).catch(function () {
    wait.hidden = true;
    if (none) none.hidden = false;
  });

  var signOut = document.getElementById('acct-out-btn');
  if (signOut) signOut.addEventListener('click', function () {
    fetch('/api/account-signout', { method: 'POST', headers: window.EGAuthHeaders(), body: '{}' })
      .catch(function () {})
      .then(function () {
        try { localStorage.removeItem('eg-session'); } catch (e) {}
        window.__egTok = '';
        window.location.href = '/join/';
      });
  });
})();

/* ------------------------------------------------------------------ *
 * The cutting room.
 *
 * Clips generated on this page collect here and are edited into one
 * film entirely in the browser: each shot is drawn onto a canvas in
 * real time while a MediaRecorder captures the canvas stream. No
 * upload, no service, no ffmpeg — and no audio, because the models
 * make none.
 * ------------------------------------------------------------------ */
(function () {
  var box = document.getElementById('montage-box');
  if (!box) return;

  var list = document.getElementById('shot-list');
  var renderBtn = document.getElementById('m-render');
  var clearBtn = document.getElementById('m-clear');
  var msg = document.getElementById('m-msg');
  var out = document.getElementById('montage-out');
  var transEl = document.getElementById('m-transition');
  var shapeEl = document.getElementById('m-shape');

  var shots = [];
  var busy = false;

  /* Sound. Nothing is uploaded: a file dropped here is decoded with the Web
     Audio API and mixed into the recording as the cut plays. `bed` runs
     under the whole film; a clip attached to a shot runs only across that
     shot, or across a run of shots sharing the same clip id, and the bed
     ducks out underneath it for exactly that stretch. */
  var bed = null;              // { name, buffer, from, gain, loop }
  var audioCtx = null;
  var clipSeq = 0;
  var bedBox = document.getElementById('m-bed');
  var bedFile = document.getElementById('m-bed-file');
  var shotFile = document.getElementById('m-shot-file');
  var shotSound = document.getElementById('m-shot-sound');
  var pendingTargets = [];

  function say(text, bad) {
    msg.textContent = text || '';
    msg.className = 'auth-msg' + (text ? (bad ? ' is-bad' : ' is-good') : '');
  }

  /* ----------------------------------------------------------- shots */

  var STILL = 3;   // seconds a still picture holds in the cut

  window.EGMontageHas = function (url) {
    return shots.some(function (s) { return s.url === url; });
  };

  window.EGMontageAdd = function (url, prompt, kind, meta) {
    if (!url || shots.some(function (s) { return s.url === url; })) return;
    meta = meta || {};

    /* A still is a shot too. It holds for three seconds and takes the same
       transitions, which is also what makes it a usable starting frame: a
       picture you liked becomes the first frame of the clip that follows. */
    if (kind === 'image') {
      var img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = url;
      var still = {
        url: url, prompt: prompt || 'A picture', kind: 'image', image: img,
        in: 0, out: STILL, duration: STILL, id: meta.id || null,
        sheet: meta.sheet || null, seed: meta.seed || null
      };
      img.addEventListener('load', paint);
      shots.push(still);
      paint();
      return;
    }

    var v = document.createElement('video');
    v.src = url;
    v.crossOrigin = 'anonymous';
    v.preload = 'metadata';
    v.muted = true;
    v.playsInline = true;
    var shot = {
      url: url, prompt: prompt || 'A clip', kind: 'video', video: v,
      in: 0, out: null, duration: null, id: meta.id || null,
      sheet: meta.sheet || null, seed: meta.seed || null
    };
    v.addEventListener('loadedmetadata', function () {
      shot.duration = v.duration;
      if (shot.out === null) shot.out = v.duration;
      paint();
    });
    shots.push(shot);
    paint();
  };

  /* ------------------------------------------------- extending a shot
   *
   * Pick a shot and the next generation grows out of it. Three things
   * travel across, strongest first:
   *
   *   1. the frame itself. For a clip it is read off a canvas at the out
   *      point, for a still it is the picture; either way it is uploaded and
   *      handed to the model as the literal first frame where the route
   *      supports image-to-video.
   *   2. the seed, so the noise does not change underneath the world.
   *   3. the continuity sheet — the exact words that described the
   *      characters, the setting, the camera, the light and the stock.
   *
   * If the browser cannot read the frame (a clip served without permissive
   * CORS headers taints the canvas) the page says so rather than pretending,
   * and the other two locks still apply.
   */
  function grabFrame(shot) {
    return new Promise(function (resolve) {
      try {
        var W = 848, H = 480;
        var canvas = document.createElement('canvas');
        var src = shot.kind === 'image' ? shot.image : shot.video;

        var paintIt = function () {
          var sw = src.videoWidth || src.naturalWidth;
          var sh = src.videoHeight || src.naturalHeight;
          if (!sw || !sh) return resolve(null);
          canvas.width = sw; canvas.height = sh;
          canvas.getContext('2d').drawImage(src, 0, 0, sw, sh);
          try { resolve(canvas.toDataURL('image/jpeg', 0.92)); }
          catch (e) { resolve(null); }          // tainted canvas
        };

        if (shot.kind === 'image') {
          if (src.complete) paintIt();
          else { src.addEventListener('load', paintIt); src.addEventListener('error', function () { resolve(null); }); }
          return;
        }

        var at = Math.max(0, (shot.out || shot.duration || 1) - 0.08);
        var done = function () { src.removeEventListener('seeked', done); paintIt(); };
        src.addEventListener('seeked', done);
        try { src.currentTime = at; } catch (e) { resolve(null); }
        setTimeout(function () { resolve(null); }, 4000);
      } catch (e) { resolve(null); }
    });
  }

  async function extendFrom(shot, index) {
    if (!window.EGExtendFrom) return;
    say('Reading the frame\u2026');
    var dataUrl = await grabFrame(shot);
    var hosted = null;

    if (dataUrl) {
      try {
        var res = await fetch('/api/upload', {
          method: 'POST',
          headers: window.EGAuthHeaders ? window.EGAuthHeaders() : { 'content-type': 'application/json' },
          body: JSON.stringify({ name: 'frame.jpg', type: 'image/jpeg', data: dataUrl })
        });
        var out = await res.json().catch(function () { return {}; });
        if (res.ok && out.url) hosted = out.url;
      } catch (e) { /* the words and the seed will have to carry it */ }
    }

    window.EGExtendFrom({
      id: shot.id || null,
      index: index + 1,
      frame: hosted,
      thumb: dataUrl || (shot.kind === 'image' ? shot.url : null),
      sheet: shot.sheet || null,
      seed: shot.seed || null,
      carried: shot.prompt
    });
    say(hosted
      ? 'Shot ' + (index + 1) + ' is the starting frame. Say what happens next.'
      : 'That clip\u2019s frame could not be read in the browser, so the description and the seed will carry it. Say what happens next.',
      !hosted);
  }

  /* ------------------------------------------------------------ sound */

  function context() {
    var C = window.AudioContext || window.webkitAudioContext;
    if (!C) return null;
    if (!audioCtx) audioCtx = new C();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    return audioCtx;
  }

  function decode(file) {
    return new Promise(function (resolve, reject) {
      var ac = context();
      if (!ac) { reject(new Error('this browser has no Web Audio')); return; }
      var reader = new FileReader();
      reader.onerror = function () { reject(new Error('the file could not be read')); };
      reader.onload = function () {
        ac.decodeAudioData(reader.result,
          function (buf) { resolve(buf); },
          function () { reject(new Error('that is not an audio file this browser can decode')); });
      };
      reader.readAsArrayBuffer(file);
    });
  }

  function clock(sec) {
    var s = Math.max(0, Number(sec) || 0);
    var m = Math.floor(s / 60);
    var r = Math.round(s % 60);
    return m + ':' + (r < 10 ? '0' : '') + r;
  }

  function paintBed() {
    if (!bedBox) return;
    if (!bed) { bedBox.hidden = true; bedBox.innerHTML = ''; return; }
    bedBox.hidden = false;
    bedBox.innerHTML = '';
    var name = document.createElement('p');
    name.className = 'sound-name';
    name.textContent = '\u266a ' + bed.name + ' \u00b7 ' + clock(bed.buffer.duration) +
      ' under the whole film';
    bedBox.appendChild(name);
    bedBox.appendChild(controls(bed, bed.buffer.duration, function () { bed = null; paintBed(); }));
  }

  /* The three things a piece of sound needs: where in the file to start,
     how loud, and a way to take it off again. */
  function controls(clip, len, remove) {
    var wrap = document.createElement('div');
    wrap.className = 'sound-controls';

    var from = document.createElement('label');
    from.innerHTML = 'Play from <input type="number" min="0" step="0.5" value="' +
      clip.from.toFixed(1) + '"><span class="muted xsmall">s of ' + clock(len) + '</span>';
    var fi = from.querySelector('input');
    fi.max = String(Math.max(0, len - 0.2).toFixed(1));
    fi.addEventListener('change', function () {
      clip.from = Math.max(0, Math.min(Number(fi.value) || 0, Math.max(0, len - 0.2)));
      fi.value = clip.from.toFixed(1);
    });
    wrap.appendChild(from);

    var vol = document.createElement('label');
    vol.innerHTML = 'Level <input type="range" min="0" max="1.5" step="0.05" value="' + clip.gain + '">';
    var vi = vol.querySelector('input');
    vi.addEventListener('input', function () { clip.gain = Number(vi.value); });
    wrap.appendChild(vol);

    if (clip === bed) {
      var loop = document.createElement('label');
      loop.className = 'check';
      loop.innerHTML = '<input type="checkbox"' + (clip.loop ? ' checked' : '') +
        '><span>Loop it if the film runs longer</span>';
      var li = loop.querySelector('input');
      li.addEventListener('change', function () { clip.loop = li.checked; });
      wrap.appendChild(loop);
    }

    var off = document.createElement('button');
    off.type = 'button';
    off.className = 'btn btn--ghost btn--small';
    off.textContent = 'Take it off';
    off.addEventListener('click', remove);
    wrap.appendChild(off);
    return wrap;
  }

  function chosenShots() {
    var picked = [];
    shots.forEach(function (s, i) { if (s.sel) picked.push(i); });
    return picked;
  }

  if (bedFile) bedFile.addEventListener('change', function () {
    var f = bedFile.files && bedFile.files[0];
    if (!f) return;
    say('Decoding ' + f.name + '\u2026');
    decode(f).then(function (buf) {
      bed = { name: f.name, buffer: buf, from: 0, gain: 0.7, loop: true };
      paintBed();
      say('Sound laid under the whole film. Set where in the file it should start.');
    }).catch(function (e) { say(e.message, true); });
    bedFile.value = '';
  });

  if (shotSound) shotSound.addEventListener('click', function () {
    pendingTargets = chosenShots();
    if (!pendingTargets.length) { say('Tick the scenes the sound belongs to first.', true); return; }
    if (shotFile) shotFile.click();
  });

  if (shotFile) shotFile.addEventListener('change', function () {
    var f = shotFile.files && shotFile.files[0];
    if (!f || !pendingTargets.length) return;
    var targets = pendingTargets.slice();
    say('Decoding ' + f.name + '\u2026');
    decode(f).then(function (buf) {
      clipSeq++;
      var clip = { id: clipSeq, name: f.name, buffer: buf, from: 0, gain: 1 };
      targets.forEach(function (i) { if (shots[i]) shots[i].audio = clip; });
      paint();
      say('\u266a ' + f.name + ' sits on ' + (targets.length === 1
        ? 'scene ' + (targets[0] + 1)
        : targets.length + ' scenes') + '. Anything already playing underneath drops out for that ' +
        'stretch and comes back after.');
    }).catch(function (e) { say(e.message, true); });
    shotFile.value = '';
    pendingTargets = [];
  });

  function total() {
    return shots.reduce(function (n, s) {
      return n + Math.max(0, (s.out || 0) - (s.in || 0));
    }, 0);
  }

  function paint() {
    list.innerHTML = '';
    if (!shots.length) {
      var li = document.createElement('li');
      li.className = 'shot-empty';
      li.textContent = 'No shots yet. Draw a picture or film a clip above and it lands here \u2014 ' +
        'then any shot can be continued from, so the next one keeps the same characters.';
      list.appendChild(li);
      renderBtn.disabled = true;
      if (clearBtn) clearBtn.hidden = true;
      return;
    }
    if (clearBtn) clearBtn.hidden = false;
    renderBtn.disabled = busy || shots.length < 1;
    if (shotSound) shotSound.disabled = !chosenShots().length;

    shots.forEach(function (s, i) {
      var li = document.createElement('li');
      li.className = 'shot';

      var thumb;
      if (s.kind === 'image') {
        thumb = document.createElement('img');
        thumb.src = s.url;
        thumb.alt = String(s.prompt).slice(0, 80);
        thumb.className = 'shot-thumb';
      } else {
        thumb = document.createElement('video');
        thumb.src = s.url + '#t=0.5';
        thumb.className = 'shot-thumb';
        thumb.muted = true;
        thumb.playsInline = true;
        thumb.preload = 'metadata';
      }

      var body = document.createElement('div');
      body.className = 'shot-body';

      var head = document.createElement('p');
      head.className = 'shot-name';
      var tick = document.createElement('input');
      tick.type = 'checkbox';
      tick.className = 'shot-tick';
      tick.checked = Boolean(s.sel);
      tick.title = 'Choose this scene, for laying sound on it';
      tick.setAttribute('aria-label', 'Select scene ' + (i + 1));
      tick.addEventListener('change', function () {
        s.sel = tick.checked;
        if (shotSound) shotSound.disabled = !chosenShots().length;
      });
      head.appendChild(tick);
      head.appendChild(document.createTextNode(' ' + (i + 1) + '. ' +
        (s.kind === 'image' ? '\u25a3 ' : '\u25b6 ') + String(s.prompt).slice(0, 90)));
      body.appendChild(head);

      var ext = document.createElement('button');
      ext.type = 'button';
      ext.className = 'btn btn--ghost btn--small shot-extend';
      ext.textContent = s.kind === 'image' ? 'Film on from this picture' : 'Continue from this shot';
      ext.title = 'Carry the characters, the setting and the camera into the next generation';
      ext.addEventListener('click', function () { extendFrom(s, i); });
      body.appendChild(ext);

      if (s.kind === 'image') {
        var hold = document.createElement('div');
        hold.className = 'shot-trim';
        hold.innerHTML = '<label>Hold <input type="number" min="0.5" step="0.5" value="' +
          s.out.toFixed(1) + '"></label><span class="muted xsmall">seconds on screen</span>';
        var hi = hold.querySelector('input');
        hi.addEventListener('change', function () {
          s.out = Math.max(0.5, Number(hi.value) || STILL);
          s.duration = s.out;
          paint();
        });
        body.appendChild(hold);
      } else if (s.duration) {
        var trim = document.createElement('div');
        trim.className = 'shot-trim';
        trim.innerHTML =
          '<label>In <input type="number" min="0" step="0.1" value="' + s.in.toFixed(1) + '"></label>' +
          '<label>Out <input type="number" min="0.1" step="0.1" value="' + s.out.toFixed(1) + '"></label>' +
          '<span class="muted xsmall">of ' + s.duration.toFixed(1) + 's</span>';
        var ins = trim.querySelectorAll('input');
        ins[0].addEventListener('change', function () {
          s.in = Math.max(0, Math.min(Number(ins[0].value) || 0, (s.out || 0) - 0.2));
          paint();
        });
        ins[1].addEventListener('change', function () {
          s.out = Math.min(s.duration, Math.max(Number(ins[1].value) || 0, s.in + 0.2));
          paint();
        });
        body.appendChild(trim);
      }

      if (s.audio) {
        var run = shots.filter(function (o) { return o.audio && o.audio.id === s.audio.id; }).length;
        var sline = document.createElement('div');
        sline.className = 'shot-sound';
        var sname = document.createElement('p');
        sname.className = 'sound-name';
        sname.textContent = '\u266a ' + s.audio.name +
          (run > 1 ? ' \u00b7 across ' + run + ' scenes' : '');
        sline.appendChild(sname);
        /* Only the first scene of a run carries the controls \u2014 it is one
           piece of sound running through, not one per scene. */
        if (!shots[i - 1] || !shots[i - 1].audio || shots[i - 1].audio.id !== s.audio.id) {
          sline.appendChild(controls(s.audio, s.audio.buffer.duration, (function (clip) {
            return function () {
              shots.forEach(function (o) { if (o.audio && o.audio.id === clip.id) o.audio = null; });
              paint();
            };
          })(s.audio)));
        }
        body.appendChild(sline);
      }

      var tools = document.createElement('div');
      tools.className = 'shot-tools';
      var snd = document.createElement('button');
      snd.type = 'button';
      snd.className = 'shot-btn';
      snd.textContent = '\u266a';
      snd.title = 'Lay a piece of sound on this scene';
      snd.addEventListener('click', function () {
        pendingTargets = [i];
        if (shotFile) shotFile.click();
      });
      tools.appendChild(snd);
      [['▲', 'Earlier', -1], ['▼', 'Later', 1]].forEach(function (b) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'shot-btn';
        btn.textContent = b[0];
        btn.title = b[1];
        btn.addEventListener('click', function () {
          var j = i + b[2];
          if (j < 0 || j >= shots.length) return;
          var tmp = shots[i]; shots[i] = shots[j]; shots[j] = tmp;
          paint();
        });
        tools.appendChild(btn);
      });
      var drop = document.createElement('button');
      drop.type = 'button';
      drop.className = 'shot-btn';
      drop.textContent = '✕';
      drop.title = 'Take it out';
      drop.addEventListener('click', function () { shots.splice(i, 1); paint(); });
      tools.appendChild(drop);

      li.appendChild(thumb);
      li.appendChild(body);
      li.appendChild(tools);
      list.appendChild(li);
    });

    var foot = document.createElement('li');
    foot.className = 'shot-total muted xsmall';
    foot.textContent = shots.length + (shots.length === 1 ? ' shot · ' : ' shots · ') +
      total().toFixed(1) + ' seconds in the cut';
    list.appendChild(foot);
  }

  if (clearBtn) clearBtn.addEventListener('click', function () {
    shots = [];
    bed = null;
    paintBed();
    out.innerHTML = '';
    say('');
    paint();
  });

  /* ---------------------------------------------------------- render */

  function drawCover(ctx, video, W, H, alpha) {
    var vw = video.videoWidth || video.naturalWidth;
    var vh = video.videoHeight || video.naturalHeight;
    if (!vw || !vh) return;
    var scale = Math.max(W / vw, H / vh);
    var w = vw * scale, h = vh * scale;
    ctx.globalAlpha = alpha;
    ctx.drawImage(video, (W - w) / 2, (H - h) / 2, w, h);
    ctx.globalAlpha = 1;
  }

  function seek(video, t) {
    return new Promise(function (res) {
      var done = function () { video.removeEventListener('seeked', done); res(); };
      video.addEventListener('seeked', done);
      try { video.currentTime = t; } catch (e) { res(); }
      setTimeout(res, 1500);
    });
  }

  /* A still is held for its hold time, with the same cross-fade into the
     next shot that a clip gets. Real time, like everything else here,
     because the recorder is capturing the canvas as it plays. */
  function holdStill(ctx, W, H, shot, next, fade) {
    return new Promise(function (resolve) {
      var t0 = performance.now();
      var span = Math.max(0.3, (shot.out || STILL) - (shot.in || 0)) * 1000;
      var nextStarted = false;
      var step = function () {
        var t = performance.now() - t0;
        if (t >= span) { resolve(nextStarted); return; }
        drawCover(ctx, shot.image, W, H, 1);
        if (next && fade > 0 && t > span - fade * 1000) {
          var k = Math.min(1, (t - (span - fade * 1000)) / (fade * 1000));
          if (!nextStarted) {
            nextStarted = true;
            if (next.kind !== 'image') {
              next.video.currentTime = next.in;
              next.video.play().catch(function () {});
            }
          }
          drawCover(ctx, next.kind === 'image' ? next.image : next.video, W, H, k);
        }
        requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }

  function playSegment(ctx, W, H, shot, next, fade, onTick) {
    return new Promise(function (resolve) {
      var v = shot.video;
      var started = false;
      var nextStarted = false;

      var step = function () {
        if (v.paused && started) return;
        var t = v.currentTime;
        if (t >= shot.out - 0.02) {
          v.pause();
          resolve(nextStarted);
          return;
        }
        drawCover(ctx, v, W, H, 1);

        if (next && fade > 0 && t > shot.out - fade) {
          var k = Math.min(1, (t - (shot.out - fade)) / fade);
          if (!nextStarted) {
            nextStarted = true;
            next.video.currentTime = next.in;
            next.video.play().catch(function () {});
          }
          drawCover(ctx, next.video, W, H, k);
        }
        if (onTick) onTick();
        requestAnimationFrame(step);
      };

      seek(v, shot.in).then(function () {
        started = true;
        v.play().then(function () { requestAnimationFrame(step); })
          .catch(function () { resolve(false); });
      });
    });
  }

  renderBtn.addEventListener('click', async function () {
    if (busy || !shots.length) return;
    if (!window.MediaRecorder || !document.createElement('canvas').captureStream) {
      say('This browser cannot record a canvas, so the montage cannot be cut here.', true);
      return;
    }
    busy = true;
    renderBtn.disabled = true;
    out.innerHTML = '';
    say('Cutting — this plays through in real time, so give it ' + total().toFixed(0) + ' seconds.');

    var size = (shapeEl.value || '854x480').split('x');
    var W = Number(size[0]), H = Number(size[1]);
    var fade = transEl.value === 'cut' ? 0 : Number(transEl.value);

    var canvas = document.createElement('canvas');
    canvas.width = W; canvas.height = H;
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = '#0a090e';
    ctx.fillRect(0, 0, W, H);

    /* ---- the sound desk ---------------------------------------------
       The canvas gives the picture; the Web Audio graph gives the track,
       and the two streams are recorded together. The bed runs from the
       first frame; a scene's own sound starts when that scene starts and
       the bed is ducked to silence for exactly as long as it plays. */
    var hasSound = Boolean(bed) || shots.some(function (sh) { return sh.audio; });
    var ac = hasSound ? context() : null;
    var dest = ac ? ac.createMediaStreamDestination() : null;
    var bedGain = null, bedSrc = null, sceneSrc = null;

    var startBed = function () {
      if (!ac || !bed) return;
      bedGain = ac.createGain();
      bedGain.gain.value = bed.gain;
      bedGain.connect(dest);
      bedSrc = ac.createBufferSource();
      bedSrc.buffer = bed.buffer;
      bedSrc.loop = Boolean(bed.loop);
      bedSrc.connect(bedGain);
      try { bedSrc.start(0, Math.min(bed.from, Math.max(0, bed.buffer.duration - 0.05))); }
      catch (e) { bedSrc = null; }
    };
    var duck = function (down) {
      if (!bedGain || !ac) return;
      bedGain.gain.cancelScheduledValues(ac.currentTime);
      bedGain.gain.setTargetAtTime(down ? 0.0001 : bed.gain, ac.currentTime, 0.05);
    };
    var startScene = function (clip) {
      if (!ac || !clip) return;
      var g = ac.createGain();
      g.gain.value = clip.gain;
      g.connect(dest);
      var src = ac.createBufferSource();
      src.buffer = clip.buffer;
      src.connect(g);
      try { src.start(0, Math.min(clip.from, Math.max(0, clip.buffer.duration - 0.05))); }
      catch (e) { return; }
      sceneSrc = src;
      duck(true);
    };
    var stopScene = function () {
      if (sceneSrc) { try { sceneSrc.stop(); } catch (e) {} sceneSrc = null; }
      duck(false);
    };

    var vstream = canvas.captureStream(30);
    var tracks = vstream.getVideoTracks().slice();
    if (dest) tracks = tracks.concat(dest.stream.getAudioTracks());
    var stream = new MediaStream(tracks);
    var mime = (dest
      ? ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
      : ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'])
      .find(function (m) { return MediaRecorder.isTypeSupported(m); }) || '';
    var rec = new MediaRecorder(stream, mime ? { mimeType: mime, videoBitsPerSecond: 4000000 } : undefined);
    var chunks = [];
    rec.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };

    var finished = new Promise(function (res) { rec.onstop = res; });
    rec.start(200);
    startBed();

    try {
      for (var i = 0; i < shots.length; i++) {
        var shot = shots[i];
        var next = shots[i + 1] || null;
        if (shot.out === null && shot.duration) shot.out = shot.duration;
        var prevClip = shots[i - 1] ? shots[i - 1].audio : null;
        if (shot.audio && (!prevClip || prevClip.id !== shot.audio.id)) startScene(shot.audio);
        say('Cutting shot ' + (i + 1) + ' of ' + shots.length + '…');
        var preRolled = shot.kind === 'image'
          ? await holdStill(ctx, W, H, shot, next, fade)
          : await playSegment(ctx, W, H, shot, next, fade);
        var nextClip = next ? next.audio : null;
        if (shot.audio && (!nextClip || nextClip.id !== shot.audio.id)) stopScene();
        if (preRolled && next) next.in = Math.min((next.out || 0) - 0.2, next.in + fade);
      }
    } catch (err) {
      say('The cut broke partway: ' + ((err && err.message) || 'unknown'), true);
    }

    stopScene();
    if (bedSrc) { try { bedSrc.stop(); } catch (e) {} bedSrc = null; }
    rec.stop();
    await finished;
    shots.forEach(function (s) { try { if (s.video) s.video.pause(); } catch (e) {} });

    var blob = new Blob(chunks, { type: 'video/webm' });
    var url = URL.createObjectURL(blob);
    out.innerHTML =
      '<figure class="draw-card"><video controls playsinline src="' + url + '"></video>' +
      '<figcaption>Your montage · ' + shots.length + ' shots · ' + Math.round(blob.size / 1024) + ' KB' +
      (hasSound ? ' · with your sound' : ' · silent') +
      '<span class="draw-meta">Cut in your browser · generated, not filmed</span></figcaption></figure>' +
      '<p><a class="btn" href="' + url + '" download="egregora-montage.webm">Download the film</a></p>';
    say('Done. The film is below, and the download keeps it.');
    busy = false;
    renderBtn.disabled = false;
    if (window.EGArrived) window.EGArrived('video', out.querySelector('.draw-card'), 'Your montage is cut.');
  });

  paint();
})();

/* ------------------------------------------------------ A key of your own
   Anyone who already pays for a picture service can hand their own key over
   for a single request. The panel below the sketch pad opens on a press,
   fills in a sensible model name for whichever house they bank with, and
   hands the details to /api/draw with the prompt. The key is held in this
   tab only — in memory by default, or in sessionStorage if the box is
   ticked, which the browser throws away when the tab closes. It is never
   written to the order's database and never logged. */
(() => {
  "use strict";
  const open = document.getElementById("bk-open");
  const panel = document.getElementById("byok-box");
  if (!open || !panel) return;

  const providerEl = document.getElementById("bk-provider");
  const modelEl = document.getElementById("bk-model");
  const keyEl = document.getElementById("bk-key");
  const baseEl = document.getElementById("bk-base");
  const baseWrap = document.getElementById("bk-base-wrap");
  const keepEl = document.getElementById("bk-keep");
  const useBtn = document.getElementById("bk-use");
  const forgetBtn = document.getElementById("bk-forget");
  const msg = document.getElementById("bk-msg");

  const DEFAULTS = {
    stability: { model: "sd3.5-large", hint: "Stability's own endpoint. Models: sd3.5-large, sd3.5-large-turbo, sd3.5-medium, core, ultra." },
    openai: { model: "gpt-image-1", hint: "OpenAI, or any service that copies its shape \u2014 give the base URL if it is not OpenAI itself." },
    huggingface: { model: "stabilityai/stable-diffusion-3.5-large", hint: "Any text-to-image model on the Hugging Face Inference API, written owner/name." },
    replicate: { model: "stability-ai/stable-diffusion-3.5-large", hint: "A Replicate model, written owner/name. Your token begins r8_." },
    fal: { model: "fal-ai/stable-diffusion-v35-large", hint: "A fal.ai route. Your key is the whole id:secret pair." }
  };

  const say = (t, bad) => {
    if (!msg) return;
    msg.textContent = t || "";
    msg.className = "auth-msg" + (bad ? " is-bad" : "");
  };

  let own = null;

  const STORE = "eg-byok";
  const remember = (rec) => {
    try {
      if (rec && keepEl && keepEl.checked) sessionStorage.setItem(STORE, JSON.stringify(rec));
      else sessionStorage.removeItem(STORE);
    } catch { /* private browsing: memory only, which is no loss */ }
  };

  const mark = () => {
    open.textContent = own ? "Your own API \u00b7 in use" : "Use your own API";
    open.classList.toggle("has-key", Boolean(own));
  };

  const shape = () => {
    const p = (providerEl && providerEl.value) || "stability";
    const d = DEFAULTS[p] || DEFAULTS.stability;
    if (modelEl) modelEl.placeholder = d.model;
    if (baseWrap) baseWrap.hidden = p !== "openai";
    say(d.hint);
  };

  open.addEventListener("click", () => {
    const show = panel.hidden;
    panel.hidden = !show;
    open.setAttribute("aria-expanded", String(show));
    if (show) {
      shape();
      if (keyEl && !own) keyEl.focus();
    }
  });
  if (providerEl) providerEl.addEventListener("change", shape);

  if (useBtn) useBtn.addEventListener("click", () => {
    const provider = (providerEl && providerEl.value) || "stability";
    const key = (keyEl && keyEl.value || "").trim();
    if (!key) { say("Paste the key first \u2014 it goes no further than the request it is used on.", true); return; }
    const model = (modelEl && modelEl.value || "").trim() || DEFAULTS[provider].model;
    const base = (baseEl && baseEl.value || "").trim();
    own = { provider, model, key, base: base || undefined };
    remember(own);
    mark();
    say("Held for this tab. The next picture is drawn through your own account on " +
      provider + ", with " + model + ". Press Forget it to go back to the order's routes.");
  });

  if (forgetBtn) forgetBtn.addEventListener("click", () => {
    own = null;
    if (keyEl) keyEl.value = "";
    remember(null);
    mark();
    say("Forgotten. Pictures go through the order's own open-weights routes again.");
  });

  try {
    const saved = JSON.parse(sessionStorage.getItem(STORE) || "null");
    if (saved && saved.provider && saved.key) {
      own = saved;
      if (providerEl) providerEl.value = saved.provider;
      if (modelEl) modelEl.value = saved.model || "";
      if (keyEl) keyEl.value = saved.key;
      if (baseEl && saved.base) baseEl.value = saved.base;
      if (keepEl) keepEl.checked = true;
      mark();
    }
  } catch { /* nothing kept */ }

  /* The drawing code asks for this when it submits. */
  window.EGOwnKey = () => own;
})();


/* ------------------------------------------- A key of your own, for film
   The same bargain as the picture box, for clips: a member who holds a key
   at fal.ai or Replicate can have the order submit the job through their
   account instead of queueing behind the house GPUs. Held in this tab only
   and sent with the one request it is used on. */
(() => {
  "use strict";
  const open = document.getElementById("vk-open");
  const panel = document.getElementById("vbyok-box");
  if (!open || !panel) return;

  const providerEl = document.getElementById("vk-provider");
  const modelEl = document.getElementById("vk-model");
  const keyEl = document.getElementById("vk-key");
  const keepEl = document.getElementById("vk-keep");
  const msg = document.getElementById("vk-msg");
  const STORE = "eg-byok-film";

  const HINT = {
    fal: "A fal.ai key is the whole id:secret pair. Leave the route empty and the model you chose " +
      "above is used; fill it in to send the job somewhere else on fal.",
    replicate: "A Replicate token begins r8_. Leave the route empty for the house model, or write " +
      "owner/name to pick another.",
    luma: "A Luma Dream Machine key. The route is the model name \u2014 ray-2, ray-flash-2 \u2014 " +
      "and ray-2 is used if you leave it empty.",
    custom: "Anything that takes a prompt over HTTPS. Give the address that starts a clip, your " +
      "key as a bearer token, and the model name if the service wants one. If asking after the job " +
      "happens at a different address, give that too and write {id} where the job id goes. The page " +
      "hands your key back with every check, because the order never keeps it."
  };

  const baseWrap = document.getElementById("vk-base-wrap");
  const statusWrap = document.getElementById("vk-status-wrap");
  const baseEl = document.getElementById("vk-base");
  const statusEl = document.getElementById("vk-status");
  const shape = () => {
    const custom = (providerEl && providerEl.value) === "custom";
    if (baseWrap) baseWrap.hidden = !custom;
    if (statusWrap) statusWrap.hidden = !custom;
  };

  const say = (t, bad) => {
    if (!msg) return;
    msg.textContent = t || "";
    msg.className = "auth-msg" + (bad ? " is-bad" : "");
  };

  let own = null;
  const remember = (rec) => {
    try {
      if (rec && keepEl && keepEl.checked) sessionStorage.setItem(STORE, JSON.stringify(rec));
      else sessionStorage.removeItem(STORE);
    } catch { /* memory only */ }
  };
  const mark = () => {
    open.textContent = own ? "Your own API \u00b7 in use" : "Use your own API";
    open.classList.toggle("has-key", Boolean(own));
  };

  open.addEventListener("click", () => {
    const show = panel.hidden;
    panel.hidden = !show;
    open.setAttribute("aria-expanded", String(show));
    if (show) {
      shape();
      say(HINT[(providerEl && providerEl.value) || "fal"]);
      if (keyEl && !own) keyEl.focus();
    }
  });
  if (providerEl) providerEl.addEventListener("change", () => {
    shape();
    say(HINT[providerEl.value] || HINT.fal);
  });

  const use = document.getElementById("vk-use");
  if (use) use.addEventListener("click", () => {
    const key = (keyEl && keyEl.value || "").trim();
    if (!key) { say("Paste the key first.", true); return; }
    const provider = (providerEl && providerEl.value) || "fal";
    const base = (baseEl && baseEl.value || "").trim();
    if (provider === "custom" && !/^https:\/\//.test(base)) {
      say("Give the https address that starts a clip on your service.", true);
      return;
    }
    own = {
      provider,
      model: (modelEl && modelEl.value || "").trim() || undefined,
      base: base || undefined,
      status: (statusEl && statusEl.value || "").trim() || undefined,
      key
    };
    remember(own);
    mark();
    say("Held for this tab. The next clip is filmed through your own account on " + own.provider + ".");
  });

  const forget = document.getElementById("vk-forget");
  if (forget) forget.addEventListener("click", () => {
    own = null;
    if (keyEl) keyEl.value = "";
    remember(null);
    mark();
    say("Forgotten. Clips queue for the order\u2019s own GPUs again.");
  });

  try {
    const saved = JSON.parse(sessionStorage.getItem(STORE) || "null");
    if (saved && saved.key) {
      own = saved;
      if (providerEl) providerEl.value = saved.provider || "fal";
      if (modelEl && saved.model) modelEl.value = saved.model;
      if (baseEl && saved.base) baseEl.value = saved.base;
      if (statusEl && saved.status) statusEl.value = saved.status;
      if (keyEl) keyEl.value = saved.key;
      shape();
      if (keepEl) keepEl.checked = true;
      mark();
    }
  } catch { /* nothing kept */ }

  window.EGOwnFilmKey = () => own;
})();

/* ------------------------------------------------------------------ *
 *  Lending the oracle a mind
 *
 *  The same arrangement as the picture and the clip. A key given here is
 *  held in this tab and sent with the question, and the server uses it for
 *  that one request and forgets it. Nothing is stored anywhere else, and
 *  the order's own written answers are still tried first.
 * ------------------------------------------------------------------ */
(() => {
  const open = document.getElementById("mk-open");
  const panel = document.getElementById("mbyok-box");
  if (!open || !panel) return;
  const providerEl = document.getElementById("mk-provider");
  const modelEl = document.getElementById("mk-model");
  const keyEl = document.getElementById("mk-key");
  const baseEl = document.getElementById("mk-base");
  const baseWrap = document.getElementById("mk-base-wrap");
  const keep = document.getElementById("mk-keep");
  const msg = document.getElementById("mk-msg");
  const STORE = "eg-byok-mind";

  const HINT = {
    google: "A Google AI Studio key begins AIza. Free, and generous: Gemini 2.0 Flash is the default " +
      "and needs no model named.",
    groq: "A Groq key begins gsk_. Free, and the fastest of the three: Llama 3.3 70B by default.",
    openrouter: "An OpenRouter key begins sk-or-. Its free tier carries several open-weights models; " +
      "leave the model empty for Llama 3.3 70B free.",
    cerebras: "A Cerebras key. Llama 3.3 70B by default, and very fast indeed.",
    mistral: "A Mistral key from La Plateforme. Mistral Small by default.",
    openai: "An OpenAI key beginning sk-. Not free, and better than free.",
    custom: "Anything that speaks the OpenAI shape. Give the full chat endpoint and the model name."
  };

  let own = null;
  const say = (t, bad) => {
    if (!msg) return;
    msg.textContent = t || "";
    msg.classList.toggle("is-bad", Boolean(bad));
    msg.classList.toggle("is-good", Boolean(t) && !bad);
  };
  const shape = () => {
    if (baseWrap) baseWrap.hidden = (providerEl && providerEl.value) !== "custom";
  };

  open.addEventListener("click", () => {
    const show = panel.hidden;
    panel.hidden = !show;
    open.setAttribute("aria-expanded", String(show));
    if (show) { shape(); say(HINT[(providerEl && providerEl.value) || "google"]); }
  });
  if (providerEl) providerEl.addEventListener("change", () => {
    shape();
    say(HINT[providerEl.value] || HINT.google);
  });

  const use = document.getElementById("mk-use");
  if (use) use.addEventListener("click", () => {
    const key = (keyEl && keyEl.value || "").trim();
    if (!key) { say("Paste the key first.", true); return; }
    const provider = (providerEl && providerEl.value) || "google";
    const base = (baseEl && baseEl.value || "").trim();
    if (provider === "custom" && !/^https:\/\//.test(base)) {
      say("Give the https address of your provider's chat endpoint.", true);
      return;
    }
    own = {
      provider,
      model: (modelEl && modelEl.value || "").trim() || undefined,
      base: base || undefined,
      key
    };
    if (keep && keep.checked) {
      try { window.sessionStorage.setItem(STORE, JSON.stringify(own)); } catch { /* no store */ }
    }
    say("The oracle will think with your key when its own writings do not fit. It is never stored on " +
      "the order's side.");
  });

  const forget = document.getElementById("mk-forget");
  if (forget) forget.addEventListener("click", () => {
    own = null;
    if (keyEl) keyEl.value = "";
    try { window.sessionStorage.removeItem(STORE); } catch { /* no store */ }
    say("Forgotten.");
  });

  try {
    const saved = JSON.parse(window.sessionStorage.getItem(STORE) || "null");
    if (saved && saved.key) {
      own = saved;
      if (providerEl && saved.provider) providerEl.value = saved.provider;
      if (modelEl && saved.model) modelEl.value = saved.model;
      if (baseEl && saved.base) baseEl.value = saved.base;
      if (keyEl) keyEl.value = saved.key;
      if (keep) keep.checked = true;
      shape();
    }
  } catch { /* nothing kept */ }

  window.EGOwnMind = () => own;
})();

/* ------------------------------------------------------------------ *
 *  One fold open at a time
 *
 *  Modern browsers do this themselves when several <details> share a
 *  name, exactly as radio buttons do. Older ones ignore the attribute
 *  entirely, so the same behaviour is enforced here for them. Nothing is
 *  forced open: a group may be wholly shut, which is how it starts.
 * ------------------------------------------------------------------ */
(() => {
  const folds = Array.from(document.querySelectorAll("details[name]"));
  if (!folds.length) return;
  /* If the browser understands the attribute, leave it alone. */
  const probe = document.createElement("details");
  if ("name" in probe) return;
  folds.forEach((d) => {
    d.addEventListener("toggle", () => {
      if (!d.open) return;
      folds.forEach((other) => {
        if (other !== d && other.getAttribute("name") === d.getAttribute("name")) other.open = false;
      });
    });
  });
})();

/* ---------------------------------------------- Gink's voice, on and off
   A switch in the corner of the answer box. The choice is remembered, and
   it is applied to the fox as soon as he wakes — he may well be still
   loading his three.js when the page settles. */
(() => {
  "use strict";
  const btn = document.getElementById("o-mute");
  const KEY = "eg-gink-muted";

  let muted = false;
  try { muted = localStorage.getItem(KEY) === "1"; } catch { muted = false; }

  window.EGVoiceMuted = () => muted;

  const applyToFox = () => {
    if (window.EGFox) {
      window.EGFox.muted = muted;
      if (muted && window.EGFox.stop) window.EGFox.stop();
      if (muted) window.__EG_PENDING_SPEECH__ = "";
      return true;
    }
    return false;
  };

  /* He arrives late, so keep offering the setting for a little while. */
  if (!applyToFox()) {
    let tries = 0;
    const t = setInterval(() => {
      if (applyToFox() || ++tries > 40) clearInterval(t);
    }, 500);
  }

  if (!btn) return;
  const label = btn.querySelector(".mute-label");

  const paint = () => {
    btn.classList.toggle("is-muted", muted);
    btn.setAttribute("aria-pressed", muted ? "true" : "false");
    if (label) label.textContent = muted ? "Gink's voice is off" : "Gink's voice is on";
    btn.setAttribute("aria-label", muted
      ? "Gink's voice is off. Turn it on."
      : "Gink's voice is on. Turn it off.");
  };

  /* Pause and carry on, and read it again from the top. */
  const holdBtn = document.getElementById("o-hold");
  const againBtn = document.getElementById("o-again");
  const paintHold = () => {
    if (!holdBtn) return;
    const fox = window.EGFox;
    const isPaused = Boolean(fox && fox.paused);
    holdBtn.textContent = isPaused ? "Carry on" : "Pause";
    holdBtn.setAttribute("aria-pressed", isPaused ? "true" : "false");
    holdBtn.disabled = muted;
    if (againBtn) againBtn.disabled = muted || !(fox && fox.lastText);
  };
  if (holdBtn) holdBtn.addEventListener("click", () => {
    const fox = window.EGFox;
    if (!fox) return;
    if (fox.paused) fox.resume(); else fox.hold();
    paintHold();
  });
  if (againBtn) againBtn.addEventListener("click", () => {
    const fox = window.EGFox;
    if (fox && fox.again) fox.again();
    paintHold();
  });
  setInterval(paintHold, 700);

  btn.addEventListener("click", () => {
    muted = !muted;
    try { localStorage.setItem(KEY, muted ? "1" : "0"); } catch { /* private window */ }
    applyToFox();
    paint();
    paintHold();
  });

  paint();
  paintHold();
})();

/* ---------------------------------------------------- Don't lose the work
   A picture takes half a minute, a clip takes several, and an oracle answer
   can take a few seconds of thinking: all of them die if the page is
   reloaded or left. So while anything is actually running, the browser is
   asked to confirm before unloading, and a link clicked inside the site
   asks the same question in plain words first.

   What counts as running is read from the page itself rather than from a
   flag somebody has to remember to clear: a working card, a thinking
   bubble, or a job registered by hand through EGWork. That way a card that
   finishes or errors stops the warning without any further bookkeeping. */
(() => {
  "use strict";

  const held = new Map();
  let seq = 0;

  /* Anything with one of these on the page means work is in flight. */
  const MARKS = [
    ".draw-card.is-working",
    ".oracle-msg.is-thinking",
    "[data-eg-working]",
    ".is-generating"
  ];

  const running = () => {
    for (const sel of MARKS) {
      if (document.querySelector(sel)) return true;
    }
    return held.size > 0;
  };

  const what = () => {
    const bits = [];
    const pics = document.querySelectorAll(".draw-card.is-working").length;
    if (pics) bits.push(pics === 1 ? "a picture is being made" : pics + " pictures are being made");
    if (document.querySelector(".oracle-msg.is-thinking")) bits.push("the oracle is still answering");
    held.forEach((label) => bits.push(label));
    if (!bits.length) return "Something is still being generated";
    const last = bits.pop();
    return (bits.length ? bits.join(", ") + " and " + last : last);
  };

  /* For anything that is not a card — an upload, a long export. */
  window.EGWork = {
    start(label) {
      const id = "w" + (++seq);
      held.set(id, String(label || "a job is running"));
      return id;
    },
    end(id) { if (id) held.delete(id); },
    busy: running,
    describe: what
  };

  window.addEventListener("beforeunload", (e) => {
    if (!running()) return;
    /* Browsers show their own wording; the string is required all the same. */
    e.preventDefault();
    e.returnValue = what() + ". Leave the page and it will be lost.";
    return e.returnValue;
  });

  /* A link inside the site never reaches beforeunload in some browsers'
     bfcache paths, and a plain confirm says more than the browser's
     boilerplate anyway. */
  document.addEventListener("click", (e) => {
    if (!running()) return;
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target && e.target.closest ? e.target.closest("a[href]") : null;
    if (!a) return;
    const href = a.getAttribute("href") || "";
    if (!href || href.startsWith("#") || a.target === "_blank" || /^(mailto:|tel:)/.test(href)) return;
    let url;
    try { url = new URL(a.href, location.href); } catch { return; }
    if (url.origin !== location.origin) return;
    if (url.pathname === location.pathname && url.search === location.search) return;
    const ok = window.confirm(
      what().charAt(0).toUpperCase() + what().slice(1) + ".\n\n" +
      "Leaving this page will abandon it \u2014 the work is not saved anywhere until it finishes. " +
      "Leave anyway?"
    );
    if (!ok) e.preventDefault();
  }, true);
})();

/* ------------------------------------------------------------------ *
 * When the age and identity check is what stands in the way, bring the
 * check itself up rather than pointing at a page and hoping. On the Join
 * page it scrolls to the section and lights it; anywhere else it opens
 * the same section in a sheet over the page, camera and all, so nobody
 * loses what they were doing in order to prove how old they are.
 * ------------------------------------------------------------------ */
(function () {
  var WHY = {
    signin: ['Sign in to go on', 'This needs an account. It takes one address and one six-digit code.'],
    verify: ['Confirm your address', 'The code we emailed has not been entered yet.'],
    identity: ['The age and identity check', 'This part of the house is kept behind a check of age. ' +
      'Let the camera look at your face, which takes seconds and keeps nothing, or show a document.']
  };

  function light(el) {
    if (!el) return;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.classList.add('is-wanted');
    setTimeout(function () { el.classList.remove('is-wanted'); }, 2600);
  }

  function sheet(reason) {
    var had = document.getElementById('check-sheet');
    if (had) { had.hidden = false; return; }
    var words = WHY[reason] || WHY.identity;
    var wrap = document.createElement('div');
    wrap.className = 'check-sheet';
    wrap.id = 'check-sheet';
    wrap.setAttribute('role', 'dialog');
    wrap.setAttribute('aria-modal', 'true');
    wrap.setAttribute('aria-label', words[0]);
    wrap.innerHTML =
      '<div class="check-pane">' +
      '<div class="check-head"><strong>' + words[0] + '</strong>' +
      '<button type="button" class="check-shut" aria-label="Close">&times;</button></div>' +
      '<p class="muted xsmall check-why">' + words[1] + '</p>' +
      '<iframe class="check-frame" title="Age and identity check" allow="camera; microphone" ' +
      'src="/join/?only=check#gate"></iframe>' +
      '<p class="muted xsmall">Nothing you were doing on this page has been lost; close this when ' +
      'you are through and carry on.</p></div>';
    document.body.appendChild(wrap);
    wrap.addEventListener('click', function (e) {
      if (e.target === wrap || e.target.classList.contains('check-shut')) close();
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  }

  function close() {
    var el = document.getElementById('check-sheet');
    if (el) el.remove();
  }

  window.EGNeedCheck = function (reason) {
    var onJoin = /^\/join\//.test(location.pathname);
    if (onJoin) {
      var block = document.getElementById(reason === 'identity' ? 'a-id-block' : 'auth-box');
      light(block || document.getElementById('gate'));
      return;
    }
    sheet(reason || 'identity');
  };

  /* The sheet tells us when the check has been passed inside it. */
  addEventListener('message', function (e) {
    if (e.origin !== location.origin || !e.data) return;
    if (e.data === 'eg-check-passed' || e.data.eg === 'check-passed') {
      close();
      location.reload();
    }
  });

  /* Any refusal that arrives with a gate on it brings the right thing up. */
  window.EGGate = function (err) {
    var g = err && (err.gate || (err.body && err.body.gate));
    if (!g) return false;
    window.EGNeedCheck(g);
    return true;
  };
})();

/* ------------------------------------------------------------------ *
 * Coming in with an account you already have.
 * ------------------------------------------------------------------ */
(function () {
  var row = document.getElementById('social-row');
  if (!row) return;
  var door = document.getElementById('social-door');
  var msg = document.getElementById('social-msg');

  var MARK = {
    google: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M21.6 12.2c0-.7-.1-1.3-.2-1.9H12v3.7h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3z"/><path fill="currentColor" d="M12 22c2.7 0 5-.9 6.6-2.5l-3.2-2.5c-.9.6-2 1-3.4 1-2.6 0-4.8-1.7-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22z"/><path fill="currentColor" d="M6.4 13.9a6 6 0 0 1 0-3.8V7.5H3.1a10 10 0 0 0 0 9z"/><path fill="currentColor" d="M12 5.9c1.5 0 2.8.5 3.8 1.5l2.8-2.8A10 10 0 0 0 3.1 7.5l3.3 2.6C7.2 7.6 9.4 5.9 12 5.9z"/></svg>',
    apple: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M16.4 12.8c0-2.3 1.9-3.4 2-3.5-1.1-1.6-2.8-1.8-3.4-1.8-1.5-.2-2.8.8-3.5.8s-1.9-.8-3.1-.8c-1.6 0-3 .9-3.8 2.3-1.6 2.8-.4 7 1.2 9.3.8 1.1 1.7 2.4 2.9 2.3 1.2 0 1.6-.7 3-.7s1.8.7 3 .7c1.3 0 2.1-1.1 2.8-2.2.9-1.3 1.3-2.6 1.3-2.7 0 0-2.4-.9-2.4-3.7zM14.1 5.4c.6-.8 1-1.9.9-3-.9 0-2 .6-2.7 1.4-.6.7-1.1 1.8-.9 2.9 1 .1 2-.5 2.7-1.3z"/></svg>',
    x: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M17.5 3h3.1l-6.8 7.8L21.8 21h-6.3l-4.9-6.4L4.9 21H1.8l7.3-8.3L2.4 3h6.4l4.4 5.9zm-1.1 16.1h1.7L7.7 4.8H5.9z"/></svg>',
    facebook: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M22 12a10 10 0 1 0-11.6 9.9v-7H7.9V12h2.5V9.8c0-2.5 1.5-3.9 3.8-3.9 1.1 0 2.2.2 2.2.2v2.4h-1.2c-1.2 0-1.6.8-1.6 1.6V12h2.7l-.4 2.9h-2.3v7A10 10 0 0 0 22 12z"/></svg>',
    github: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-3.2 19.5c.5.1.7-.2.7-.5v-1.7c-2.8.6-3.4-1.3-3.4-1.3-.4-1.2-1.1-1.5-1.1-1.5-.9-.6.1-.6.1-.6 1 .1 1.5 1 1.5 1 .9 1.6 2.4 1.1 3 .9.1-.7.4-1.1.6-1.4-2.2-.3-4.6-1.1-4.6-5 0-1.1.4-2 1-2.7-.1-.3-.4-1.3.1-2.7 0 0 .8-.3 2.7 1a9.4 9.4 0 0 1 5 0c1.9-1.3 2.7-1 2.7-1 .5 1.4.2 2.4.1 2.7.6.7 1 1.6 1 2.7 0 3.9-2.4 4.7-4.6 5 .4.3.7.9.7 1.9v2.8c0 .3.2.6.7.5A10 10 0 0 0 12 2z"/></svg>',
    discord: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M19.3 5.4A16 16 0 0 0 15.4 4l-.3.5c1.4.3 2.6.9 3.7 1.6a13 13 0 0 0-11.6 0C8.3 5.4 9.6 4.8 11 4.5L10.6 4a16 16 0 0 0-3.9 1.4C4.2 9.1 3.5 12.7 3.8 16.3a16 16 0 0 0 4.9 2.5l.9-1.5c-.8-.3-1.6-.7-2.3-1.2l.6-.4a11.4 11.4 0 0 0 10.2 0l.6.4c-.7.5-1.5.9-2.3 1.2l.9 1.5a16 16 0 0 0 4.9-2.5c.4-4.2-.7-7.8-2.9-10.9zM9.7 14.3c-1 0-1.7-.9-1.7-1.9s.8-1.9 1.7-1.9 1.8.9 1.7 1.9c0 1-.8 1.9-1.7 1.9zm4.6 0c-1 0-1.7-.9-1.7-1.9s.8-1.9 1.7-1.9 1.8.9 1.7 1.9c0 1-.7 1.9-1.7 1.9z"/></svg>'
  };

  fetch('/api/oauth', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action: 'ready' })
  })
    .then(function (r) { return r.json(); })
    .then(function (d) {
      var open = (d.providers || []).filter(function (p) { return p.ready; });
      if (!open.length) return;            /* no keys pasted: no empty row */
      door.hidden = false;
      row.innerHTML = open.map(function (p) {
        return '<a class="social-btn social-btn--' + p.id + '" href="/api/oauth?go=' + p.id +
          '&back_to=' + encodeURIComponent(location.pathname + location.hash) + '">' +
          (MARK[p.id] || '') + '<span>Continue with ' + p.label + '</span></a>';
      }).join('');
      if (open.some(function (p) { return p.id === 'x'; })) {
        msg.textContent = 'X does not hand over an email address, so an account made that way ' +
          'cannot receive letters until you add one.';
      }
    })
    .catch(function () { /* the emailed code is always there */ });
})();



/* ------------------------------------------------------------------ *
 * The order's door on /ask-ed/, and sending a generation to the live
 * files folder.
 *
 * Opening the door is one call to /api/freeai with the passcode: if the
 * doors answer, the pass was right. It is kept for this tab only. Once it
 * is held, every finished generation on the page grows an extra button that
 * files the picture or the film into the live archive's folders, where the
 * Director's Desk can put it straight on air.
 * ------------------------------------------------------------------ */
(function () {
  var root = document.getElementById('ask-admin');

  window.EGToLiveFiles = function (url, title, mime) {
    var pass = (window.EGAdminPass && window.EGAdminPass()) || '';
    if (!pass) return Promise.reject(new Error('The order\u2019s door is not open on this page.'));
    return fetch('/api/live', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'file-add', pass: pass, url: url, title: title || 'A generation',
        mime: mime || '', folder: 'generations'
      })
    }).then(function (r) {
      return r.json().then(function (d) {
        if (!r.ok || !d.ok) throw new Error((d && d.error) || 'The archive refused it.');
        return d;
      });
    });
  };

  /* The button itself, hung under a finished card. */
  window.EGFileButton = function (card, url, title, kind) {
    if (!card || !url) return;
    if (!(window.EGAdminIn && window.EGAdminIn())) return;
    if (card.querySelector('.card-to-files')) return;
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'btn btn--ghost btn--small card-to-files';
    b.textContent = 'Send to the live files';
    b.addEventListener('click', function () {
      b.disabled = true;
      b.textContent = 'Filing\u2026';
      window.EGToLiveFiles(url, title, kind === 'image' ? 'image/png' : 'video/webm')
        .then(function (d) {
          b.textContent = 'In the live files \u00b7 ' + d.folder;
          b.classList.add('is-on');
        })
        .catch(function (err) {
          b.disabled = false;
          b.textContent = 'Would not file: ' + err.message;
        });
    });
    card.appendChild(b);
  };

  /* When the door opens, every card already on the page gets one too. */
  window.addEventListener('eg-admin-in', function () {
    document.querySelectorAll('.draw-card').forEach(function (card) {
      var media = card.querySelector('img, video');
      if (!media || !media.src) return;
      var cap = card.querySelector('figcaption');
      window.EGFileButton(card, media.src,
        (cap && cap.textContent.slice(0, 160)) || 'A generation',
        media.tagName === 'IMG' ? 'image' : 'video');
    });
  });

  if (!root) return;
  var aa = function (n) { return root.querySelector('[data-aa=' + n + ']'); };
  var msg = aa('msg');
  var say = function (t, bad) {
    if (!msg) return;
    msg.textContent = t || '';
    msg.className = 'auth-msg' + (t ? (bad ? ' is-bad' : ' is-good') : '');
  };

  aa('open').addEventListener('click', function () {
    var shut = aa('panel').hidden;
    aa('panel').hidden = !shut;
    aa('open').setAttribute('aria-expanded', shut ? 'true' : 'false');
    aa('open').textContent = shut ? 'Close the admin door' : 'Admin Only';
    if (shut && aa('pass')) aa('pass').focus();
  });

  aa('signin').addEventListener('click', function () {
    var pass = (aa('pass') && aa('pass').value) || '';
    if (!pass) { say('The passcode, please.', true); return; }
    say('Opening\u2026');
    fetch('/api/freeai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'status', pass: pass })
    }).then(function (r) {
      return r.json().then(function (d) {
        if (!r.ok) throw new Error((d && d.error) || 'That did not open it.');
        if (aa('pass')) aa('pass').value = '';
        if (window.EGAdminKeep) window.EGAdminKeep(pass);
        say('Open. The passcode is kept for this tab only.');
      });
    }).catch(function (err) { say(err.message, true); });
  });
})();
